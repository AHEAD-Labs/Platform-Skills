---
description: Creates Microsoft Outlook/Teams calendar invites end-to-end — gathers meeting details, resolves attendees, drafts subject/body, enforces Teams meeting settings, previews for approval, creates the event, and verifies the result; supports a batch mode for scheduling multiple meetings from a source document.
name: outlook-event-creation
---
# Outlook Invite Creation

## When this activates
Use this skill whenever the user asks to create, schedule, draft, or send an Outlook or Teams calendar invite/meeting — including single invites, calendar-only blocks with no attendees, or a batch of meetings sourced from a document (roster, plan, contact list).

Also activates whenever the user's message starts with the literal command `/outlook` (optionally followed by details, e.g. `/outlook sync with Anna Thursday 2pm`) — treat this as an explicit shorthand invocation of this skill and proceed to Step 1, using any details supplied after the command to pre-fill fields instead of re-asking for them.

Background on *why* these rules exist (platform testing notes, requirements, acceptance criteria) lives in `spec.md` — read it if you need justification for a rule, not to execute the workflow. Guardrails live in `references/guardrails.md`. Reusable templates live in `assets/`. A payload-building helper lives in `scripts/build_event_payload.py`.

## Step 1: Gather meeting details
Collect, per the field table in `spec.md` §Inputs:
- Subject, start date/time, duration (**always ask explicitly**; default to 30 minutes and say so if omitted), end time (calculated), time zone (**default to the organizer's own local time zone** — e.g. America/New_York for an ET-based organizer — never UTC).
- Attendees (required for an invite; optional for a personal block).
- Body/description — ask whether the organizer will supply it or wants it drafted.
- Location, show-as, importance, recurrence, categories, calendar ID — optional.

## Step 2: Resolve attendees
Resolve every attendee to a verified company email address — never invent one. Use a JSON array of `{email, name}` objects (see `assets/attendee-example.json`). Omit the field entirely for a calendar-only block with no invitees.

## Step 2.5: Check required attendees' availability
Before drafting the preview, call `outlook_get_calendar_schedule` (`schedules`: every **required** attendee's email; `start_time`/`end_time`: the proposed slot in the organizer's time zone; `availability_view_interval`: 30) and read each attendee's `availabilityView` digit for that slot (`0` free, `1` tentative, `2` busy, `3` out of office, `4` working elsewhere).

Never silently schedule over a **required** attendee who is `2` (busy) or `3` (OOO) at the proposed time — both are existing conflicts, not just OOO. Surface it in the preview and ask the organizer to: pick a different time, proceed anyway despite the conflict, or move that person to optional. A required attendee who is `1` (tentative) is worth a passing mention in the preview but is not a blocker; `0` (free) and `4` (working elsewhere) need no mention. Optional attendees' busy/OOO status is worth a passing mention but is not a blocker. Skip this check only for a personal calendar-only block with no invitees, or a batch run's shared-settings step (still run it per-meeting before each individual preview).

When proactively picking or suggesting a time (rather than checking a time the organizer already specified), prefer a slot where every required attendee shows `0` (free) or `4` (working elsewhere) before ever proposing one where a required attendee is `2` (busy) or `3` (OOO).

## Step 3: Draft subject and body
- Subject format (only when drafted, not organizer-supplied): `[High-level topic] Specific subject` — high-level topic wrapped in square brackets, e.g. `[AI Hive]`, with no hyphen between the bracket and the specific subject. See `assets/subject-body-format.md` for the pattern and body template.
- Body: greeting, 1–2 sentence purpose/context, short topic list, courteous scheduling note, organizer's name.
- Always append the mandatory attribution footer in `assets/footer.html` as the **final** element of the body, rendered as HTML (`is_html: true`). Never plain-text it, omit it, or add content after it.

## Step 3.5: Build start/end times in the organizer's time zone
Compute `start_datetime`/`end_datetime` as an RFC3339 string carrying the correct, DST-aware UTC offset for the organizer's actual `time_zone` on that date (`scripts/build_event_payload.py`'s `_localize` helper does this) — never hardcode an offset and never default to `Z`/UTC. See `references/guardrails.md` for why this matters.

## Step 4: Configure Teams meeting settings
Every meeting invite must set `is_online_meeting: true` and `online_meeting_provider: teamsForBusiness`. The create-event action has no recording/transcription parameter at all, so **no** recording/transcription state (`Record and transcribe`, `Transcribe only`, or `Off`) can be applied automatically — do not offer it as an intake choice or claim it was set.

If the organizer wants recording/transcription, tell them it must be configured manually in Teams Meeting Options after the event is created (see `spec.md` §Manual handling for recording/transcription).

## Step 5: Preview and approve
Use `scripts/build_event_payload.py` to assemble and validate the event JSON (enforces Teams fields, footer, end-time math). Show a complete preview — subject, time, attendees, Teams status, body, **and any required-attendee OOO conflicts found in Step 2.5** — and create the event only after organizer approval. Treat any change to attendees, time, Teams settings, or body as material, requiring a new preview (including a new availability check if the time or required attendee list changed).

## Step 6: Create and verify
Create the event, then verify the returned record against the checklist in `spec.md` §Acceptance Criteria (subject, start/end/time zone, attendees, `isOnlineMeeting`, `onlineMeetingProvider`, `onlineMeetingUrl`, `isDraft`). Report the result with a link to the event, and remind the organizer that any recording/transcription state is a manual, post-creation step in Teams Meeting Options, not something this workflow can confirm or apply.


## Batch mode
When the organizer wants several related meetings scheduled from a source document: read the document, present the extracted list for confirmation (create nothing yet), ask once for shared settings (window, time zone, duration, subject/body preference), resolve every attendee, check for likely duplicate events, show one full preview table, and create only after approval. Verify each event independently — one failure must never be reported as a batch success. Use `assets/batch-prompt-template.txt` as a copy-ready starting prompt.