# Subject and body drafting templates

## Subject line (only when drafted, not organizer-supplied)
Pattern: `[High-level topic] Specific subject`

- **High-level topic**: short label for the meeting type — a team, program, or initiative name — wrapped in square brackets, e.g. `[AI Hive]`, `[Team Name]`.
- **Specific subject**: brief, descriptive phrase naming purpose and people, e.g. `Intro Call - Jane & Sam`.
- No hyphen or other separator between the bracketed high-level topic and the specific subject — just a space.

Example: `[Team Name] Intro Call - Jane & Sam`
Example: `[AI Hive] Knowledge Share - Matt & Alexis`

If the organizer supplies a specific subject, use it as provided — do not reformat it into this pattern.

## Body (only when drafted, not organizer-supplied)
- Brief greeting.
- Purpose and relevant context in one or two sentences.
- Short, readable list of discussion topics.
- Courteous scheduling note and the organizer's name.
- Mandatory attribution footer (`assets/footer.html`) appended as the final element.

Example:

```text
Hello [Attendee],

I'm reaching out to connect and learn more about your role, current priorities, and any advice you might have.

Discussion topics:
* Introductions and current areas of focus
* Your priorities and perspective on [topic]
* Relevant opportunities, dependencies, or lessons learned
* Advice or potential next steps

Please feel free to suggest an alternate time if this slot is not convenient. I look forward to connecting.

Best regards,
[Organizer name]
```
