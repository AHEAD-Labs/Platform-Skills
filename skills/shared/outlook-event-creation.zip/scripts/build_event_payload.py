"""Build and validate an Outlook create-event payload for the Outlook Invite Creation skill.

Not a network call — this only assembles/validates the JSON that the Outlook
create-event action expects, enforcing the workflow's mandatory rules:
  - end_datetime is derived from start_datetime + duration_minutes unless given
  - Teams fields are always set for a meeting invite
  - the mandatory HTML attribution footer is appended as the final body element

Recording/transcription is NOT settable through the create-event action (the
action has no such parameter) and is therefore always a manual, post-creation
Teams Meeting Options step — this builder does not accept or track a
recording/transcription choice.

Usage:
    from build_event_payload import build_event_payload
    payload = build_event_payload(
        subject="Team Sync",
        start_datetime="2026-09-02T13:30:00",
        time_zone="America/New_York",
        duration_minutes=30,
        attendees=[{"email": "jane.doe@example.com", "name": "Jane Doe"}],
        body_html="<p>Agenda...</p>",
        is_invite=True,
    )
"""
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

FOOTER_HTML = (
    '<p style="font-size: smaller;"><em>This meeting was created using Glean. '
    'If you believe this meeting was scheduled incorrectly, please contact the sender.</em></p>'
)


def _localize(dt_string: str, time_zone: str) -> str:
    """Return an RFC3339 datetime string with an explicit UTC offset.

    The Outlook create-event action's schema requires start_datetime/end_datetime to
    match a strict 'date-time' format (an explicit UTC offset is mandatory) even though
    its own examples show a bare local time like "2025-01-03T11:00:00" -- that bare form
    is rejected with "Does not match format 'date-time'".

    The offset must be the organizer's real, DST-aware offset for that specific date in
    `time_zone` (e.g. America/New_York is -04:00 in September, -05:00 in January) -- never
    a hardcoded offset and never "Z"/UTC. Hardcoding or defaulting to UTC is what causes
    events to be created for the wrong wall-clock hour, or to *look* like they were
    scheduled in UTC when the organizer expected their own local zone (e.g. ET).

    If the caller already supplied an offset-qualified or "Z"-suffixed string, it is
    trusted as-is and returned unchanged.
    """
    dt = datetime.fromisoformat(dt_string)
    if dt.tzinfo is not None:
        return dt_string
    localized = dt.replace(tzinfo=ZoneInfo(time_zone))
    return localized.isoformat()


def build_event_payload(
    subject: str,
    start_datetime: str,
    time_zone: str,
    duration_minutes: int = 30,
    end_datetime: str | None = None,
    attendees: list[dict] | None = None,
    body_html: str | None = None,
    is_invite: bool = True,
    location: str | None = None,
    show_as: str | None = None,
    importance: str | None = None,
) -> dict:
    start_datetime = _localize(start_datetime, time_zone)

    if end_datetime is None:
        start_dt = datetime.fromisoformat(start_datetime)
        end_datetime = (start_dt + timedelta(minutes=duration_minutes)).isoformat()
    else:
        end_datetime = _localize(end_datetime, time_zone)

    payload = {
        "subject": subject,
        "start_datetime": start_datetime,
        "end_datetime": end_datetime,
        "time_zone": time_zone,
    }

    if is_invite:
        if not attendees:
            raise ValueError("At least one verified attendee email is required for an invite.")
        payload["attendees_info"] = attendees
        payload["is_online_meeting"] = True
        payload["online_meeting_provider"] = "teamsForBusiness"

        body = body_html or ""
        if FOOTER_HTML not in body:
            body = body.rstrip() + "\n" + FOOTER_HTML
        elif not body.rstrip().endswith(FOOTER_HTML):
            raise ValueError("Footer must be the final element of the body.")
        payload["body"] = body
        payload["is_html"] = True

    if location:
        payload["location"] = location
    if show_as:
        payload["show_as"] = show_as
    if importance:
        payload["importance"] = importance

    return payload
