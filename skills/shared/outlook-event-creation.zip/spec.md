# Outlook Invite Creation — Specification

Status: Draft, adapted from Matt Mason's spec for SDD review.

This spec is the background/justification document for the `SKILL.md` workflow: the problem it solves, goals/non-goals, users, requirements, and acceptance criteria. It answers *why* the skill works the way it does; `SKILL.md` is the operative "brain" that says *what to do*.

## Problem
Creating Outlook/Teams invites manually is repetitive and error-prone: organizers forget to enable Teams, omit the standard attribution footer, or don't verify the created event actually matches what was requested. There is no consistent, repeatable pattern for drafting subjects/bodies or handling batches of related meetings.

## Goals
- Provide a single, repeatable intake → draft → preview → create → verify flow for Outlook/Teams invites.
- Guarantee every invite includes a Teams link.
- Guarantee a consistent, professional drafted subject/body when the organizer doesn't supply their own, including a mandatory attribution footer.
- Support scheduling multiple related meetings from a source document in one reviewable batch.
- Never report success unless the returned Outlook event record confirms it.

## Non-goals
- Does not support creating unsent/draft-only Outlook events — current platform testing shows `isDraft: false` on every created event; draft behavior is unsupported until retested.
- Does not automate any recording/transcription state (`Record and transcribe`, `Transcribe only`, or `Off`) — the create-event action has no such parameter, so recording/transcription is always a manual, post-creation Teams Meeting Options step.
- Does not modify or delete previously created events.

## Users
Any AHEAD employee scheduling Outlook/Teams meetings through Glean — single ad hoc invites or batches of related meetings (e.g., onboarding rounds, stakeholder interviews) sourced from a plan/roster document.

## Known platform constraints (from manual testing)
- The Outlook create-event action successfully creates events and adds attendees, but every event tested so far returned `isDraft: false` — draft/unsent invites should be treated as unsupported.
- A Teams link is only created when online-meeting fields are explicitly set (`is_online_meeting: true`, `online_meeting_provider: teamsForBusiness`); it is not created by default.
- The create-event action does not expose recording/transcription parameters at all — none of `Record and transcribe`, `Transcribe only`, or `Off` can be set through it. Testing initially treated `Record and transcribe`/`Off` as automated, but organizer reports confirmed the setting was never actually applied; recording/transcription now always requires manual configuration in Teams Meeting Options after creation.
- `start_datetime`/`end_datetime` require a strict RFC3339 'date-time' format with an explicit UTC offset; a bare local time (matching the tool's own documented examples) fails validation with "Does not match format 'date-time'".
- CONFIRMED (2026-09-16 testing): once that offset is supplied, the create-event action permanently stores the event's `start.timeZone`/`end.timeZone` as `UTC`, regardless of the `time_zone` parameter's value or format (tested both `America/New_York` and `Eastern Standard Time`). This is a real create-event action limitation, not just a display/response quirk — `originalStartTimeZone`/`originalEndTimeZone` in the created record read `UTC`, and Outlook's edit UI shows "(UTC) Coordinated Universal Time". The absolute instant is always correct (DST-aware offset computed via `scripts/build_event_payload.py`), but the stored zone label cannot be made to say anything other than UTC through this action alone.
- `outlook_update_calendar_event` documents naive (no-offset) `start_datetime`/`end_datetime` examples paired with `time_zone`; whether that avoids the same UTC-normalization on an existing event is unverified as of this writing — treat as an unconfirmed workaround to test before promising it fixes the label.

## Functional requirements
| Requirement | Detail |
| --- | --- |
| Required event fields | subject, start_datetime, end_datetime, time_zone |
| Required invite fields | attendees_info (≥1 verified email), body, is_online_meeting: true, online_meeting_provider: teamsForBusiness |
| Duration handling | Always ask explicitly; default to 30 minutes and state the default was applied when omitted |
| Attendee resolution | Verified company email required; never invented; flagged if ambiguous/missing |
| Subject drafting | `[High-level topic] Specific subject` pattern when drafted (bracketed topic, e.g. `[AI Hive]`, no hyphen after the bracket); use organizer wording verbatim if supplied |
| Body drafting | Greeting, purpose, topic list, scheduling note, sign-off, then mandatory HTML footer as the final element |
| Recording/transcription | Not configurable via the create-event action; always a documented manual step in Teams Meeting Options after creation, regardless of which state the organizer wants |
| Batch mode | Single planning/approval cycle; one preview table; per-meeting verification; duplicate-event check before creation |
| Availability check | Query `outlook_get_calendar_schedule` for every required attendee before the preview; flag (never silently override) any OOO slot (`availabilityView == 3`) and let the organizer choose reschedule / proceed / demote to optional |

## Non-functional requirements
- Every invite creation must be preceded by an organizer-approved preview; no silent creation.
- No claim (draft status, recording/transcription applied, Teams enabled) may be made unless confirmed by the returned event record or Teams Meeting Options. Recording/transcription must never be presented as an automated intake choice.
- A failure in a batch must never be represented as a success for the rest of the batch.
- Recording/transcription notice must be given to participants before any session is recorded/transcribed; objections must be honored.

## Acceptance criteria
An invite created through this workflow is considered correct when the returned event record confirms:
- `subject`, `start`, `end`, and time zone match the intended request.
- `attendees` contains the correct people and verified email addresses.
- `isOnlineMeeting` is `true` and `onlineMeetingProvider` is `teamsForBusiness`, with a populated `onlineMeetingUrl`.
- `isDraft` is reported accurately (expected `false` given current platform behavior).
- The body ends in the mandatory HTML attribution footer with no trailing content.
- Recording/transcription is always reported as a manual, post-creation step to be completed in Teams Meeting Options — never claimed as applied by the create-event action.

## Manual handling for recording/transcription
The create-event action has no recording/transcription parameter, so this is always a manual step regardless of which state (`Record and transcribe`, `Transcribe only`, `Off`) the organizer wants:
1. Create the event as normal (Teams-enabled, no recording/transcription claim made).
2. After creation, open the meeting's Teams Meeting Options (from the Outlook invite or inside the Teams meeting).
3. Set the desired recording/transcription state there.
4. Confirm the change was applied in Teams Meeting Options before reporting it to the organizer as done — never report it as applied based on the create-event response alone.

## Recommended test cases
- Teams-enabled event with no attendees (link-generation test)
- Teams invite where recording/transcription is requested and handed off for manual configuration (any state)
- Single required attendee; multiple required + optional attendees
- Invalid or ambiguous attendee name
- User requests an unsent draft (expected: unsupported, explained)
- User changes time after preview (expect new preview)
- Batch with one intentionally conflicting/duplicate meeting

## Cross-check: does another skill avoid the UTC time-zone label?
Checked `meeting_scheduler_native` (2026-09-16): its own Round 1 instructions specify the identical Outlook format — `UTC with Z, YYYY-MM-DDTHH:MM:SSZ` — for `OUTLOOK_CALENDAR_CREATE_EVENT`. It uses the same underlying action as this skill, so it inherits the same `originalStartTimeZone: UTC` limitation; it is not a viable alternate path for a UTC-free Outlook invite. (Its Google Calendar path is different — flat local wall-clock + IANA `timeZone`, no offset — and does preserve the real zone, but that only applies to Google Calendar, not this Outlook/O365 tenant.)

## Sources
- [Microsoft Outlook tools — Glean documentation](https://docs.glean.com/tools/connector/outlook-tools)
- [Outlook Meeting Information when Scheduling Meetings — AHEAD IT Knowledge](https://aheadit.service-now.com/kb?id=kb_article&sysparm_article=KB0010421)
- [Teams Meeting missing from Outlook — AHEAD IT Knowledge](https://aheadit.service-now.com/kb?id=kb_article&sysparm_article=KB0010072)
- [Updates to Recording and Transcription Policies — AHEAD](https://archie.ahead.com/redir/27349)
- [Overview: Recording and transcription for Teams meetings, events, and calls — Microsoft Learn](https://learn.microsoft.com/en-us/microsoftteams/recording-transcription-overview)
- [Manage Teams meeting auto recording — Microsoft Learn](https://learn.microsoft.com/en-us/microsoftteams/manage-teams-auto-recording)
