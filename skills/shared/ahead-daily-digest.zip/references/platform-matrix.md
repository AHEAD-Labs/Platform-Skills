# Platform matrix: ahead-daily-digest

This file is for reviewers. The digest does not need it at run time.

## Shared contract

Both surfaces install the same folder and run the same `SKILL.md`. The contract is `SPEC.md`, and the four shared rules are in `references/ahead-shared-rules.md`. The skill is a chat-layer skill on both surfaces: not a Glean Agent, no schedule, no trigger, no file output.

## Side by side

| Concern | Glean Assistant | Claude chat |
|---|---|---|
| What gets installed | A personal Skill, from Settings > Skills > Add > Upload a Skill | A custom skill, from Customize > Skills > + > Create skill, uploading the zip |
| Zip layout | The zip holds the `ahead-daily-digest/` folder. Glean accepted it on 2026-09-24. | The zip must hold the `ahead-daily-digest/` folder, and the folder name must match the skill name. Accepted on 2026-09-24. |
| Frontmatter | `name` and `description` drive the skill. The AHEAD keys are builder metadata. | Same |
| Prerequisites | Skills turned on for the person by a Glean admin | Skills and code execution turned on in organization settings, and the Glean connector connected, with its read tools allowed |
| How it is invoked | Routing by description, most reliable in thinking mode; asking for it by name; or the slash command `/ahead-daily-digest` | Routing by description, asking for it by name, or `/ahead-daily-digest`, which worked on 2026-09-24 |
| Where the data comes from | Glean's own connectors: Outlook mail and calendar, Teams channels and group chats, Teams DMs where the person has turned them on, SharePoint and OneDrive. Jira, Salesforce and ServiceNow only where the person already has access. | The Glean connector only, which is AHEAD's approved route. Microsoft 365 connected directly is turned off in the chat. |
| New access | None. The skill sees only what the person can already see. | Same |
| Shared rules file | Glean loads the relevant portions of a skill, so `SKILL.md` also carries each rule as one line | Reference files load on demand, so `SKILL.md` carries each rule as one line |
| Write tools present during a run | Whatever actions Glean Assistant offers the person. Not inventoried here. | The Glean connector's write tools: mail drafts, Word and Excel files, and SharePoint changes including deletes and permissions. Pilot safeguard: set them to ask. |
| Follow-up request to act | A new request, handled by Glean Assistant with its own confirmations | A new request, handled by Claude with its own confirmations. Some actions, such as accepting an invite, may not be available through the Glean connector; Claude says so. |
| Memory | Never the source of an item. Since 0.2.0 it holds the saved time zone. | Same |
| Handing off the whole request | Not applicable | Claude may pass the whole request to Glean's assistant through the connector. The log records it, and that run mostly reflects Glean. |
| Links | Links to items as Glean returns them | Links to items as the Glean connector returns them |
| Time zone seen in 0.1.0 | The person's own zone, as intended | Eastern, taken from individual events instead of the person's own zone. A defect, fixed in 0.1.1. |
| Time zone seen in 0.1.1 | Not run yet | The Glean profile listed only a country, so the digest used UTC and said so. 0.1.2 also accepts the zone the person states or keeps in their preferences. |
| Current time | No issue seen so far | Not given to the assistant by default, though the code sandbox clock works. In 0.1.1 the digest said it couldn't see the time and listed the whole day. 0.1.2 tells it to find the current time first. |
| Sources named in 0.1.0 | Calendar, email, and Glean's own chats and artifacts. Teams chats and channels not named, an open finding. | Email, calendar, and chats and channels |
| Sources named in 0.1.1 | Not run yet | Teams chats and channels, Glean-indexed calendar events, and Glean activity and profile. The calendar lookup wasn't approved and email search came back empty, and the checked line named both. |
| Delivery (0.2.0) | An interactive artifact in Canvas when the admin's Interactive artifact setting is on, else a Canvas document, else chat. The chat summary comes with a page or document. | An HTML file opened in the chat, filled by code, else a document, else chat. The chat summary comes with a page or document. |
| Time zone (0.4.0) | The request, a saved zone, or the zone the person's calendar shows; otherwise Central Time as AHEAD's default. Never searched for. | The request, a saved zone, the person's Claude preferences, or their own invites in what was already read; otherwise Central Time. Never searched for. |
| Speed (0.4.0) | Each source read once | Each source read once, side by side; the page filled with code in one step, so the fonts never pass through the conversation |
| Saving the time zone | Glean memory, where AHEAD's deployment has it, only when the person states, confirms or corrects the zone | Claude's memory, on the same terms. A new save may not reach the next new chat right away. |
| Page fonts and links | On Sep 28 Glean read the 0.2.0 binary fonts as text and corrupted them, so the page fell back to a system font. Since 0.3.0 the fonts ship as base64 text; a Glean re-run confirms the fix. Links inside the artifact are not yet verified, so the chat summary carries them. | The Sep 25 page had a byte-perfect font; links open from the page |
| Cost and retention | Each artifact uses FlexCredits and stays in the Library and Glean search until deleted | Kept with the conversation |
| Sharing | Possible where Chat Sharing is on. The skill never shares. | Artifacts can be published. The skill never does. |
| Pages seen on 0.2.0 | Sep 28: an interactive page like Claude's, with the font corrupted | Sep 25: an interactive page; a cluttered calendar stacked clash flags into unreadable text |
| Kill switch | Turn the skill off in Settings > Skills | Turn the skill off in Customize > Skills |
| Test conditions | The log notes whether thinking mode was on | A normal chat outside any project, the Glean connector as the only data connector, its write tools set to ask |

## Intentional differences

On Claude, the data is Glean's view of the person's work, read by a different assistant. Differences in what gets picked, how items are worded, or how the still-open check lands are expected, and they are what the parity case compares. Both surfaces accept the slash command.

## Parity

P-1 runs one morning on both surfaces a few minutes apart and compares the user-visible contract: the shape, the window, whether anything under "needs you" was already handled, and whether the checked line is accurate. Each surface passes on its own evidence. Parity is not claimed until both tracks have real runs, and a Claude run is never evidence for Glean, or the reverse.

## To verify on the first 0.2.0 runs

On Glean: whether the Interactive artifact setting is on at AHEAD, whether a skill can have Glean build its artifact from the template, whether links inside the artifact open, and whether the embedded font loads. On Claude: whether a newly saved time zone reaches the next new chat right away. None of these blocks use, because each has a fallback.

## Platform details verified

On 2026-09-24, Glean accepted the zip with the skill folder inside, and both surfaces accepted the AHEAD frontmatter keys (SPEC Section 12).
