# ahead-daily-digest

Version 0.5.0. Status: Approved, for the Enterprise Skills Launch. Owner: Akbar Aman (akbar.aman@ahead.com), Enterprise AI. Signed off by Akbar Aman (Enterprise AI, owner) on 2026-09-28 for 0.4.1, recorded in `approved-by` and `approved-date`. The second approval, from Grace Gallagher (Solutions Engineering), the decision-maker for rollout beyond the owner, was recorded on 2026-09-28 in `second-approval-by` and `second-approval-date`, approving the package for the Enterprise Skills Launch. This is a rollout decision, not new test evidence: 0.4.x and 0.5.0 evaluation cases stay `not_run`, and org-wide publication beyond the launch still goes through the separate AHEAD eTech org-wide skill review.

This README covers install and use for the Enterprise Skills Launch.

## What it does

Ask Claude chat or Glean Assistant chat for a read on your day and you get three things: what needs you today, your meetings with anything worth knowing, and what got resolved since your last working day. It takes about a minute to take in.

Every run gives you an interactive page in AHEAD's colors and a two- or three-sentence summary in chat, together, whether you name the skill or just ask about your day, and even when you ask it to plan or realign the day. On the page you can switch every time between Eastern, Central, Mountain, Pacific and UTC, tap a meeting for its details, see a "now" line move through your day, and mark items handled on the page. If a page can't be made, you get a document with the same summary. Ask for it "in chat" and you get a plain chat reply instead.

By default it covers from the start of your last working day. Name another window if you want one, such as "since Friday" or "I was out Monday and Tuesday".

It never sends, replies, accepts, declines or edits anything, and it suggests next steps only as text. If you then ask for something in the same chat, such as drafting a reply, that is a normal request, and the assistant handles it with its usual confirmations. It sees only what you can already see, gets no new access, and never shares or publishes the page.

## Your time zone

Times use Central Time (America/Chicago), AHEAD's default, unless the digest already knows yours: a zone you name in the request, one you gave in an earlier run and it saved, one in your preferences, or the one your own calendar or the invites you organized show. It never searches just to find your time zone and never stops to ask. The header and the chat summary say which zone it used and where it came from. If you're elsewhere, use the switch on the page for Eastern, Mountain, Pacific or UTC, or tell the digest your zone once and it will remember it.

## What to ask

Ask about your day as a whole, in your own words: "What does my day look like?", "Need to realign on my day", "Help me plan today", "What should I focus on today?", "Give me an overview of my day", "Catch me up, I was out yesterday" or "Prep me for today". A request to plan or realign the day gets the same digest, with the open stretches and first steps pointed out. On either surface you can also type `/ahead-daily-digest`. Add "in chat" for a plain chat reply.

It is not for prep for one specific meeting (use ahead-meeting-prep-and-notes), a look back over the week (use ahead-weekly-recap), a single calendar or inbox question such as "When is my next meeting?", a summary of one inbox or channel, or requests to send, reply or accept.

## Install on Glean

1. In Glean, go to Settings > Skills, click Add, choose Upload a Skill, and select `ahead-daily-digest.zip`.
2. The skill appears under the Personal tab. Make sure it is turned on.
3. Use thinking mode when you ask, since Glean's skill routing works best there.

Uploading a zip with the same skill name later offers to replace the existing skill. The page needs your Glean admin's Interactive artifact setting; without it you get a document instead.

## Install on Claude

Claude needs two things first. Your organization must have Skills and code execution turned on (organization owners do this in Organization settings > Plugins & skills), and you need the Glean connector connected. The Glean connector is AHEAD's approved route to your mail, calendar, chats and documents on Claude, so don't use a Microsoft 365 connector with this skill.

1. Go to Customize > Skills, click +, then Create skill, and upload `ahead-daily-digest.zip`.
2. Make sure the skill is toggled on.

For pilot runs on Claude, use a normal chat outside any project, turn the Microsoft 365 connector off for that chat, and set the Glean connector's write tools to ask, so nothing can be written without your approval. Leave its read tools allowed, or approve them when asked.

## Zip layout

The zip holds the `ahead-daily-digest` folder at its root, including its `assets` folder. Both Glean and Claude accepted this layout on 2026-09-24, so the same zip goes to both. Since 0.3.0 the package holds no binary files: the fonts are base64 text, because Glean reads binary files as text and corrupts them.

## What has been checked

The 0.3.1 handoff checks, validator runs and template renders are in the handoff note delivered with the package. A QA pass in the build chat on Sep 28 found that the 0.3.0 sample called an updated invite new, called email unreadable after one way of reading it failed, claimed nothing had closed when something had, and missed an earlier Friday ask, and that the page had four robustness gaps; 0.3.1 fixes all eight. No 0.3.1 runs are recorded yet, so both 0.3.1 tracks are `not_run`, and nothing here claims 0.3.1 works on either surface until the owner's live runs and the fresh-chat QA are done.

Earlier versions are recorded in `evals/evals.json` as evidence for their own versions. On 0.2.0, both surfaces produced the interactive page. Claude's page on Sep 25 had a byte-perfect font, but a cluttered calendar stacked three clash flags into unreadable text, and some notes used words like "tonight" that a live page contradicts. Glean's run on Sep 28 corrupted the font, started its first passage at midnight, used a system word, and listed the owner's own finished work as resolved. 0.3.0 addresses each of these.

## Limitations

On Glean, the page needs the admin's Interactive artifact setting, and each page uses FlexCredits. Pages stay in your Library and in Glean search until you delete them. Links inside a Glean page may not open, because its sandbox allows scripts only, so the chat summary carries the links.

On Claude, a newly saved time zone may not reach a brand-new chat right away. The assistant may also hand the whole request to Glean's assistant instead of reading the data itself, in which case the answer mostly reflects Glean. With only the Glean connector, some follow-up actions, such as accepting an invite, may not be available.

On both, Teams DMs appear only if you have turned them on in Glean. Jira, Salesforce and ServiceNow are used only if you can already read them; the digest does not need them. The default window counts Monday to Friday and does not know about holidays, so name a window after time off. An older ask that is due today can be missed if nothing in the window mentions it. The word budget and line limits are starting values that will be tuned from the pilot.

## Files

| File | What it is |
|---|---|
| `SKILL.md` | The instructions both surfaces run |
| `references/ahead-shared-rules.md` | The four shared rules, frozen at v1.0 and identical across AHEAD's skills |
| `assets/digest-template.html` | The page template, with its data format described at the top |
| `assets/poppins-latin-400-normal.woff2.b64.txt`, `-500-`, `-600-` | The Poppins brand font as base64 text, inserted into each page as it is |
| `assets/Poppins-OFL.txt` | The font's license |
| `SPEC.md` | The contract, acceptance criteria and open items |
| `references/comparison-matrix.md` | The baselines and golden references, what was taken, what was kept and what was rejected |
| `references/platform-matrix.md` | How Glean and Claude each meet the contract |
| `evals/evals.json` | Test cases for 0.4.1, all `not_run` so far, and the recorded runs of earlier versions |
| `LICENSE-APACHE-2.0` | License and notice for the adapted material |

## Provenance

The digest adapts two Apache-2.0 skills from anthropics/knowledge-work-plugins, now cited at commit da38ec1, where both files are byte-identical to the earlier pin 1c7187c4: the enterprise-search digest skill, in daily mode only, and the rules of the sales daily-briefing skill, condensed with nothing CRM-related, plus its hidden "How it adapts" idea since 0.3.0. From Glean's catch-up skill (gleanwork/agent-plugins, MIT, commit 93bf39d) it re-expresses the vetting pass, the quiet-day shape and the path for a source that isn't connected. It also borrows what Glean's Plan my day template covers, and from Anthropic's example morning brief the still-open check and the page's structure and voice principles. Descriptions follow Anthropic's skill-creator and Glean's skill-creation guide. Everything is re-expressed in this package's own words and code. The page's look follows the AHEAD brand skill, and the Poppins font is used under the SIL Open Font License. Details are in `references/comparison-matrix.md`.

## Governance and open items

This is approved for the Enterprise Skills Launch: Grace Gallagher, who owns the rollout decision beyond the owner's own pilot install, approved it for the launch on 2026-09-28. Org-wide publication beyond the launch still goes through the separate AHEAD eTech org-wide skill review, and a passing validator or a good pilot log is not that approval. For AHEAD AI tools, policies or governance questions, see the AHEAD AI HIVE or your eTech team contact.

Open for Grace: the builder's validator only accepts the builder's own package and stops on binary files; each Glean page uses FlexCredits at a scale of about 3,000 people a day; pages pile up in Glean Libraries and search; and people can share their own digest org-wide where Chat Sharing is on, though the skill never does.

## Change notes

- **2026-09-28, 0.5.0.** Grace Gallagher, the decision-maker named for rollout beyond the owner, approved the package for the Enterprise Skills Launch. `second-approval-by` and `second-approval-date` move from pending to recorded, and status moves from Pilot to Approved. Evaluation cases for 0.4.x and 0.5.0 stay `not_run`; this is a rollout decision, not test evidence, and AC-16 is reworded so a status change is never read as completed testing. The SPEC is updated to match.
- **2026-09-28, 0.4.1.** The owner's rule on earlier summaries, added word for word as rule 8: "Earlier digests, recaps, briefs, and AI summaries, including ones this skill made, are never a source. Build every run fresh from the person's mail, calendar, chats, and documents, and cite the original item." The time zone wording now says a saved zone is one the person gave in an earlier run, so it doesn't read as an earlier digest being used as a source. The owner signed off on 0.4.1, and the frontmatter keeps a second approval, from a role above the owner, as pending. The SPEC and evals are updated to match.
- **2026-09-28, 0.4.0.** From the owner's timing run on Claude, where too many searches made runs slow. Central Time is now the default time zone; the digest uses another zone only when it already has one, and never searches for it or takes it from invites other people organized. Reading is capped at one read per source, side by side, with at most one more per source when the first came back empty or short, and other work systems are read only when asked for. Where code runs, the page is filled in one step so the fonts never pass through the conversation. The template defaults to Central and says so. A QA failure example on 0.3.x is folded in too: a meeting is called new only when its invite was seen arriving, parts of the day such as "early afternoon" are no longer used to say when things happen, promises due today count as needs, the chat shows only the summary with no narration, the first name is never looked up, and the wording uses plain punctuation. The SPEC, platform matrix and evals are updated to match.
- **2026-09-28, 0.3.3.** From the owner's live QA, where a request about the day came back as a time-blocked checklist in chat instead of the page. Every run now makes the page and the summary together in one pass, however it was started and whatever the request asks for, and it never answers with a schedule, checklist or plan in chat instead. The page is named again in the description's first sentence, as it was in 0.2.0, the wording that made a plan sound like the answer is gone, and the body now opens with what to make and how to deliver it. This returns the page to the description on purpose, against the kit's pattern, because the versions without it drifted to text. The SPEC and evals are updated to match.
- **2026-09-28, 0.3.2.** From the owner's live QA on Glean, where "need to realign on my day today" didn't reach the digest. The description now covers any request about the day as a whole, including an overview, a rundown, a plan, priorities or a reset, with phrasings such as "need to realign on my day", "help me plan today", "what should I focus on today" and "daily brief", while every neighbor stays excluded. A request to plan or realign the day gets the same digest, with open stretches and first steps pointed out rather than a separate schedule. The SPEC and evals are updated to match, with four trigger cases added and the missed trigger recorded as 0.3.1 evidence.
- **2026-09-28, 0.3.1.** Fixes from the build-chat QA pass. An invite is called new or changed only from the invite itself. A source is called unreadable only after a second way of reading it also comes back empty, and a source that gives only its newest items is read again for the rest of the window. The empty-state lines now read "Nothing needs you today." and "Nothing resolved worth your time." The page no longer goes blank when the date is missing, makes repeated ids unique, gives a time zone outside the five its own button and a readable name, and says "No timed meetings today." when there are only all-day events. The SPEC, evals and template comment are updated to match; one eval case (EDGE-7) and two assertions per normal case are added, and the 0.3.0 sample is recorded as 0.3.0 evidence.
- **2026-09-28, 0.3.0.** From the owner's kit, approved narrowly. The description is rewritten to lead with how people ask, with "Use when" and "Do not use" lines naming the sibling skills; the delivery mechanics it used to carry live in the body (D1). The fonts ship as base64 text, inserted as they are (D2). The time zone never blocks: it comes from the request, a saved zone, the account or meetings the person organized, else UTC, and the header and summary always name it and its source (D3). Cluttered calendars: personal blocks are muted and never flagged, others' away holds become a line, declined and canceled events are left out, all-day events sit above the track, clashes are only between accepted or tentative meetings, clash flags merge so labels never collide, compact pills keep their title as a tooltip, and the empty detail box is hidden (D4). Already resolved means someone else closed it, never the person's own work (D5). No relative time words in data (D6). Passages start with the working day (D7). No system words in output (D8). Meeting notes and resolved items are vetted, quiet days have a set shape, a source that isn't connected gets one line, and a hidden "How it adapts" section covers thin data (D9). Template fields `zoneSource`, `also`, `kind`, `allDay` and `meetingsNote` support D3 and D4. Provenance is re-pinned to da38ec1. The SPEC, both matrices and the evals are updated to match; seven eval cases are added, and every 0.3.0 result starts as not run. Held for a later pass: plain-words item titles, a no-narration rule, and routing evals from the sign-off sheet.
- **2026-09-25, 0.2.0.** The interactive AHEAD-branded page with a plain-language chat summary, then a document, then chat; the clock by running code; the time zone saved once; an assets folder.
- **2026-09-24, 0.1.2.** Current time found before dropping ended meetings; UTC fallback when no time zone is found.
- **2026-09-24, 0.1.1.** Times in the person's own zone, outside attendees as company and count, and notifications with no ask left out.
- **2026-09-24, 0.1.0.** First pilot package.
