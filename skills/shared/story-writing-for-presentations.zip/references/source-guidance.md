# Source Guidance — Story Writing for Presentations

## Provenance

This reference distills the two user-supplied presentations. It is implementation guidance, not a replacement for the source decks or platform documentation.

1. `AHEAD_Research_To_Presentation_In_Glean.pptx` — research-to-presentation workflow, four stages, evidence classification, outline structure, conclusion-led titles, visual communication, and review gates.
2. `AHEAD_Stop_Asking_AI_Questions_Start_Briefing_It  - Knox.pptx` — outcome-first briefing, GCCO, relevant context, grounding, controlled clarification, audience adaptation, measurable constraints, finished-artifact definitions, and critique/refinement.

## Distilled principles

### Brief before search

Start with the audience, objective, desired decision or action, and definition of winning. Do not begin by collecting slides or asking for a full deck from an underspecified request.

### Use a professional brief

Capture role, context, task, instructions, criteria, audience, sources, constraints, and output. GCCO—Goal, Context, Constraints, Output—is a compact thinking checklist. The objective should explain the business outcome the work must protect or produce, not merely the action to perform.

### Ground the story

Use relevant source material and enterprise context. Separate confirmed facts, assumptions, conflicts, and open questions. Preserve citations, dates, and source links for material claims. Grounding improves traceability but does not remove the need for human verification.

### Make clarification consequential

Ask only questions where the answer could materially change the recommendation, audience treatment, or deliverable. Keep the question set bounded; do not turn the workflow into an interrogation.

### Build the story before the slides

Use a four-stage quality-controlled workflow: Research → Outline → Slides → Presentation. The default narrative sequence is context → problem → insight → recommendation → action. Write the executive storyline in three to five sentences and give each slide one conclusion.

### Make titles carry the argument

Prefer conclusion-led titles over topic labels. A sequence of titles should let a reader understand the story even before reading the body. The body should prove or explain the title's conclusion.

### Use purposeful visuals

Use diagrams for processes, comparisons, architectures, and decision paths. Visuals should explain the idea, not merely decorate it. Put detailed evidence in notes or footnotes when appropriate.

### Engineer the generated draft

Review every slide for accuracy, substance, visual quality, and delivery readiness. Verify names, numbers, technical claims, recommendations, hierarchy, readability, spacing, rendering, speaker guidance, transitions, and likely questions. Treat generated slides as a structured starting point, not automatically client-ready material.

### Iterate and challenge

Treat the first answer as raw material: critique, challenge with stakeholder personas, refine, and validate against the objective. Use measurable boundaries instead of vague adjectives, and define the finished artifact explicitly.

## Design decisions derived from the sources

| Source principle | Skill behavior |
|---|---|
| Outcome before slides | Require goal, audience, decision, and winning criteria before research or design |
| Research as a quality gate | Require source provenance and claim classification |
| Outline before deck | Make the conclusion-led outline a first-class output and checkpoint |
| One conclusion per slide | Require a conclusion-led title and evidence for every slide |
| Visuals explain ideas | Recommend diagram types based on the reasoning task |
| Generated deck is a draft | Require four-lens review and human handoff status |
| Briefing beats vague prompting | Extract context, constraints, output, and examples before drafting |
| Grounding over invention | Refuse unsupported customer-specific claims and flag missing information |
| Controlled questions | Ask no more than five consequential questions |
| First answer is raw material | Run critique and refinement for consequential work |
