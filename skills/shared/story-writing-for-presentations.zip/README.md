# Story Writing for Presentations

An approved AHEAD paired skill package for creating outcome-first, evidence-grounded presentation stories and PowerPoint drafts in Claude or Glean.

## Package contents

Install packages (what users receive in Glean and Claude):

- `SKILL.md` — the skill instructions the runtime follows.
- `references/source-guidance.md` — distilled storytelling guidance the skill loads at runtime.
- `SPEC.md` — the full contract: purpose, triggers, inputs and outputs, guardrails, acceptance criteria, and open items. Read this to understand why the skill behaves the way it does.
- `README.md` — this overview, install steps, and release status.

Source package only (for building, testing, and review):

- `references/comparison-matrix.md` — source principles mapped to implementation and tests.
- `references/platform-matrix.md` — Claude/Glean mapping and platform verification items.
- `evals/evals.json` — test prompts and pass/fail assertions.
- `scripts/validate_package.py` and `scripts/build_install_packages.py` — package checks and the install-package builder.

`SPEC.md` mentions these source-only files; they are available from the skill owner.

Dependency: `ahead-branding` ≥ 1.1.0 supplies templates, brand rules, the brand validator, and Brand Marketing review routing. This package routes to it rather than duplicating brand values.

## Intended behavior

The skill is triggered by presentation-creation intent. It first creates a professional brief, gathers or inspects authoritative evidence, classifies claims, writes a three-to-five-sentence storyline, and builds a conclusion-led slide outline. It stops at an outline checkpoint before full deck construction unless the user explicitly asks for immediate generation and the platform supports the requested artifact.

## Validation (source package)

Run:

```bash
python3 scripts/validate_package.py
```

The validator checks required files, required frontmatter, referenced resources, JSON validity, and minimum evaluation coverage. It does not prove platform behavior, source freshness, visual quality, or security approval.

## Packaging

This folder is the **source package**: the full contract, evaluations, and validators used to review and maintain the skill. Users install a lighter **install package** built from it by `scripts/build_install_packages.py`:

| File | Source package | Install packages |
|---|:---:|:---:|
| `SKILL.md` | ✓ | ✓ (Claude copy nests AHEAD fields under `metadata:`) |
| `references/source-guidance.md` | ✓ | ✓ |
| `SPEC.md`, `README.md` | ✓ | ✓ |
| `references/comparison-matrix.md`, `references/platform-matrix.md` | ✓ | — |
| `evals/evals.json`, `scripts/` | ✓ | — |

Rebuild after any change (source package only):

```bash
python3 scripts/validate_package.py
python3 scripts/build_install_packages.py --out <output-dir>
```

## Install

**Glean (org-wide):** a Glean admin replaces the existing org skill `story-writing-for-presentations` with the Glean install package and confirms it shows version 1.0.0.

**Claude:** Settings → Capabilities → Skills → Upload skill, and select the Claude install package. For Claude Code, unzip into `~/.claude/skills/`.

**Branding dependency:** both platforms use the existing `ahead-branding` skill (1.1.0 or later). Install it alongside this skill wherever this skill is installed. When the branding refinements are released, update `ahead-branding`; this skill needs no change.

## Release status

v1.0.0 — Approved by the AHEAD eTech team for org-wide installation in Glean (recorded 2026-09-27). Owner: Grace Gallagher, AHEAD Enterprise AI. Runtime evaluations are `not_run`. Generated decks remain drafts until human review. Open items are tracked in `SPEC.md` §12.
