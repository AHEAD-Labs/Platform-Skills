#!/usr/bin/env python3
"""Deterministic structural and release-gate checks for this skill package."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ERRORS: list[str] = []
WARNINGS: list[str] = []

def error(message: str) -> None:
    ERRORS.append(message)

def warning(message: str) -> None:
    WARNINGS.append(message)

def read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except OSError as exc:
        error(f"cannot read {path.relative_to(ROOT)}: {exc}")
        return ""

def parse_frontmatter(text: str) -> dict[str, str]:
    if not text.startswith("---\n"):
        error("SKILL.md must start with YAML frontmatter")
        return {}
    end = text.find("\n---\n", 4)
    if end < 0:
        error("SKILL.md frontmatter is not closed")
        return {}
    values: dict[str, str] = {}
    for line in text[4:end].splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if ":" not in line:
            error(f"invalid frontmatter line: {line}")
            continue
        key, value = line.split(":", 1)
        values[key.strip()] = value.strip()
    return values

def check_files() -> None:
    required = [
        "SKILL.md", "SPEC.md", "README.md", "evals/evals.json",
        "references/comparison-matrix.md", "references/platform-matrix.md",
        "references/sdd-spec-template.md", "references/testing-guide.md",
        "scripts/validate_package.py",
    ]
    for relative in required:
        if not (ROOT / relative).is_file():
            error(f"required file is missing: {relative}")

def check_metadata(skill_text: str, spec_text: str, evals: dict) -> dict[str, str]:
    fm = parse_frontmatter(skill_text)
    required = ["name", "description", "version", "owner", "team", "approved-by", "approved-date", "ahead-platform", "sensitivity", "publication-status"]
    for key in required:
        if not fm.get(key):
            error(f"frontmatter field is missing or empty: {key}")
    if fm.get("name") != "ahead-skill-package-builder":
        error("frontmatter name must be ahead-skill-package-builder")
    if fm.get("name") and not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", fm["name"]):
        error("frontmatter name must be lowercase kebab-case")
    if not fm.get("description", "").strip():
        error("frontmatter description must be a non-empty single line")
    if fm.get("team") != "Enterprise AI":
        error("frontmatter team must be Enterprise AI")
    if not re.fullmatch(r"\d+\.\d+\.\d+", fm.get("version", "")):
        error("frontmatter version must be semantic versioning")
    spec_version = re.search(r"^- \*\*Version:\*\*\s*(\S+)", spec_text, re.MULTILINE)
    if not spec_version:
        error("SPEC.md is missing its version field")
    elif spec_version.group(1) != fm.get("version"):
        error("SKILL.md and SPEC.md versions must match")
    spec_team = re.search(r"^- \*\*Team:\*\*\s*(.+)$", spec_text, re.MULTILINE)
    if not spec_team or spec_team.group(1).strip() != "Enterprise AI":
        error("SPEC.md team must be Enterprise AI")
    if evals.get("version") != fm.get("version"):
        error("SKILL.md and evals/evals.json versions must match")
    if evals.get("skill_name") != fm.get("name"):
        error("evaluation skill_name must match frontmatter name")
    return fm

def check_references(skill_text: str, spec_text: str) -> None:
    combined = skill_text + "\n" + spec_text
    pattern = re.compile(r"(?<![A-Za-z0-9_/-])(?:SPEC\.md|(?:references|evals|scripts|assets)/[A-Za-z0-9_.-]+)")
    for reference in sorted(set(pattern.findall(combined))):
        if not (ROOT / reference).is_file():
            error(f"referenced resource is missing: {reference}")

def check_evals(evals: dict) -> None:
    if evals.get("status") not in {"not_run", "passed", "failed"}:
        error("evaluation set status must be not_run, passed, or failed")
    cases = evals.get("evals")
    if not isinstance(cases, list) or not cases:
        error("evals must be a non-empty list")
        return
    required_types = {"happy-path": 2, "edge-case": 1, "non-trigger": 1, "guardrail-mode": 2, "resource-integrity": 1, "platform-parity": 1, "security-regression": 1, "artifact-validation": 1}
    counts: dict[str, int] = {}
    seen_ids: set[str] = set()
    for case in cases:
        case_id = str(case.get("id"))
        if case_id in seen_ids:
            error(f"duplicate evaluation id: {case_id}")
        seen_ids.add(case_id)
        case_type = case.get("type")
        counts[case_type] = counts.get(case_type, 0) + 1
        for field in ("id", "type", "prompt", "status"):
            if field not in case:
                error(f"evaluation {case_id} is missing field: {field}")
        if case.get("status") not in {"not_run", "passed", "failed"}:
            error(f"evaluation {case_id} has invalid status")
        assertions = case.get("assertions")
        if not isinstance(assertions, list) or not assertions:
            error(f"evaluation {case_id} must have non-empty assertions")
            continue
        for index, assertion in enumerate(assertions, 1):
            if not isinstance(assertion, dict):
                error(f"evaluation {case_id} assertion {index} must be an object")
                continue
            for field in ("id", "text", "spec_refs", "passed", "evidence"):
                if field not in assertion:
                    error(f"evaluation {case_id} assertion {index} is missing field: {field}")
            if assertion.get("passed") not in {None, True, False}:
                error(f"evaluation {case_id} assertion {index} passed must be true, false, or null")
            if not isinstance(assertion.get("spec_refs"), list) or not assertion.get("spec_refs"):
                error(f"evaluation {case_id} assertion {index} must reference a spec requirement")
    for case_type, minimum in required_types.items():
        if counts.get(case_type, 0) < minimum:
            error(f"evaluation coverage needs at least {minimum} case(s) of type {case_type}")

def check_sensitive_literals() -> None:
    patterns = [
        (r"AKIA[0-9A-Z]{16}", "AWS access key"),
        (r"\bsk-[A-Za-z0-9]{20,}\b", "API token"),
        (r"(?i)api[_-]?key\s*[:=]\s*[^\s`]+", "inline API key"),
        (r"(?i)client[_-]?secret\s*[:=]\s*[^\s`]+", "inline client secret"),
    ]
    deprecated_terms = ("AI" + "-Enablement", "AI" + " Enablement")
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.name.endswith(".pyc"):
            continue
        text = read(path)
        for pattern, label in patterns:
            if re.search(pattern, text):
                error(f"possible {label} found in {path.relative_to(ROOT)}")
        if any(term in text for term in deprecated_terms):
            error(f"outdated team terminology found in {path.relative_to(ROOT)}")

def release_gate(fm: dict[str, str], spec_text: str, evals: dict) -> None:
    if fm.get("publication-status") not in {"Approved", "Published"}:
        error("release gate: publication-status is not Approved or Published")
    if fm.get("approved-by", "").startswith("PENDING"):
        error("release gate: approval evidence is still pending")
    if evals.get("status") != "passed":
        error("release gate: evaluation set is not marked passed")
    if any(case.get("status") != "passed" for case in evals.get("evals", [])):
        error("release gate: one or more evaluation cases are not passed")
    for line in spec_text.splitlines():
        if re.match(r"^\s*-\s*`?\[NEEDS (?:INPUT|PLATFORM VERIFICATION)", line):
            error(f"release gate: unresolved open item: {line.strip()[:110]}")

def install_gate(fm: dict[str, str], spec_text: str, evals: dict) -> None:
    """Readiness to install in the owner's own Claude or Glean workspace."""
    if fm.get("approved-by", "").startswith("PENDING") or fm.get("approved-date", "").startswith("PENDING"):
        error("install gate: owner sign-off is not recorded")
    if fm.get("publication-status") not in {"Pilot", "Approved", "Published"}:
        error("install gate: publication-status must be Pilot, Approved, or Published")
    for line in spec_text.splitlines():
        if re.match(r"^\s*-\s*`?\[NEEDS (?:INPUT|PLATFORM VERIFICATION)", line):
            error(f"install gate: unresolved open item: {line.strip()[:110]}")
    for case in evals.get("evals", []):
        for assertion in case.get("assertions", []):
            if assertion.get("passed") is True and not re.search(r"\d{4}-\d{2}-\d{2}", str(assertion.get("evidence", ""))):
                error(f"install gate: assertion {assertion.get('id')} is marked passed without dated evidence")


def main() -> int:
    check_files()
    skill_text = read(ROOT / "SKILL.md")
    spec_text = read(ROOT / "SPEC.md")
    eval_text = read(ROOT / "evals/evals.json")
    try:
        evals = json.loads(eval_text)
    except json.JSONDecodeError as exc:
        error(f"evals/evals.json is invalid JSON: {exc}")
        evals = {}
    fm = check_metadata(skill_text, spec_text, evals)
    check_references(skill_text, spec_text)
    check_evals(evals)
    check_sensitive_literals()
    if "--release-gate" in sys.argv:
        release_gate(fm, spec_text, evals)
    elif "--install-gate" in sys.argv:
        install_gate(fm, spec_text, evals)
        if evals.get("status") == "not_run":
            warning("install permitted at the current publication status, but runtime evaluations are not_run; the package is not runtime-validated")
    else:
        if fm.get("publication-status") == "Draft":
            warning("package is Draft; this is a structural check, not an approval")
        if evals.get("status") == "not_run":
            warning("runtime evaluations are not_run")
    for message in WARNINGS:
        print(f"WARN: {message}")
    if ERRORS:
        for message in ERRORS:
            print(f"FAIL: {message}")
        print(f"RESULT: FAIL ({len(ERRORS)} error(s))")
        return 1
    print("RESULT: PASS (package integrity checks)")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
