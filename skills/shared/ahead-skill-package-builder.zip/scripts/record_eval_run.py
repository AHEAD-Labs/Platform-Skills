#!/usr/bin/env python3
"""Record runtime evaluation results with mandatory evidence.

This script does NOT execute the skill. A human runs each case in the target
runtime (Claude or Glean), then records the observed result here so that every
pass is attributable, dated, and evidenced.

Usage:
  python3 scripts/record_eval_run.py --show
  python3 scripts/record_eval_run.py --case 1 --assertion 1-1 --result pass \
      --runtime Claude --run-by grace.gallagher@ahead.com \
      --evidence "Claude run 2026-09-12; transcript sharepoint://.../case1.md lines 40-72"
  python3 scripts/record_eval_run.py --verify
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVALS = ROOT / "evals" / "evals.json"
MIN_EVIDENCE = 25
BANNED_EVIDENCE = (
    "looks good", "looked good", "seems right", "high quality", "n/a", "na",
    "not run", "tbd", "todo", "assumed", "should pass", "trust me", "obvious",
)
VALID_RUNTIMES = ("Claude", "Glean")


def load() -> dict:
    return json.loads(EVALS.read_text(encoding="utf-8"))


def save(data: dict) -> None:
    tmp = EVALS.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    tmp.replace(EVALS)


def check_evidence(text: str) -> list[str]:
    problems: list[str] = []
    stripped = text.strip()
    if len(stripped) < MIN_EVIDENCE:
        problems.append(f"evidence must be at least {MIN_EVIDENCE} characters and name where it is stored")
    if stripped.lower() in BANNED_EVIDENCE or any(b == stripped.lower() for b in BANNED_EVIDENCE):
        problems.append("evidence is a subjective placeholder, not an observation")
    for banned in BANNED_EVIDENCE:
        if banned in stripped.lower() and len(banned) > 5:
            problems.append(f"evidence contains non-evidence phrase: {banned}")
            break
    if not re.search(r"\d{4}-\d{2}-\d{2}", stripped):
        problems.append("evidence must include the run date in YYYY-MM-DD form")
    return problems


def recompute(data: dict) -> None:
    for case in data.get("evals", []):
        flags = [a.get("passed") for a in case.get("assertions", [])]
        if any(f is False for f in flags):
            case["status"] = "failed"
        elif flags and all(f is True for f in flags):
            case["status"] = "passed"
        else:
            case["status"] = "not_run"
    statuses = [c.get("status") for c in data.get("evals", [])]
    if any(s == "failed" for s in statuses):
        data["status"] = "failed"
    elif statuses and all(s == "passed" for s in statuses):
        data["status"] = "passed"
    else:
        data["status"] = "not_run"


def show(data: dict) -> int:
    print(f"set status: {data.get('status')}  version: {data.get('version')}")
    for case in data.get("evals", []):
        done = sum(1 for a in case.get("assertions", []) if a.get("passed") is not None)
        total = len(case.get("assertions", []))
        print(f"  {str(case.get('id')):<6} {case.get('type'):<20} {case.get('status'):<9} {done}/{total} assertions recorded")
    return 0


def verify(data: dict) -> int:
    failures: list[str] = []
    for case in data.get("evals", []):
        for assertion in case.get("assertions", []):
            if assertion.get("passed") is None:
                continue
            problems = check_evidence(str(assertion.get("evidence", "")))
            for problem in problems:
                failures.append(f"{case.get('id')}/{assertion.get('id')}: {problem}")
    if data.get("status") == "passed":
        for case in data.get("evals", []):
            if case.get("status") != "passed":
                failures.append(f"set marked passed but case {case.get('id')} is {case.get('status')}")
    if failures:
        for line in failures:
            print(f"FAIL: {line}")
        print(f"RESULT: FAIL ({len(failures)} evidence problem(s))")
        return 1
    print("RESULT: PASS (recorded results carry dated evidence)")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case")
    parser.add_argument("--assertion")
    parser.add_argument("--result", choices=["pass", "fail"])
    parser.add_argument("--evidence")
    parser.add_argument("--runtime", choices=list(VALID_RUNTIMES))
    parser.add_argument("--run-by")
    parser.add_argument("--show", action="store_true")
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()

    data = load()
    if args.show:
        return show(data)
    if args.verify:
        return verify(data)

    missing = [n for n, v in (("--case", args.case), ("--assertion", args.assertion),
                              ("--result", args.result), ("--evidence", args.evidence),
                              ("--runtime", args.runtime), ("--run-by", args.run_by)) if not v]
    if missing:
        print(f"FAIL: missing required argument(s): {', '.join(missing)}")
        return 2

    problems = check_evidence(args.evidence)
    if problems:
        for problem in problems:
            print(f"FAIL: {problem}")
        print("RESULT: FAIL (result not recorded)")
        return 1

    for case in data.get("evals", []):
        if str(case.get("id")) != str(args.case):
            continue
        for assertion in case.get("assertions", []):
            if str(assertion.get("id")) != str(args.assertion):
                continue
            assertion["passed"] = args.result == "pass"
            assertion["evidence"] = f"{args.runtime} runtime; {args.evidence} (recorded by {args.run_by})"
            recompute(data)
            data["tested_by"] = args.run_by
            data["tested_date"] = date.today().isoformat()
            save(data)
            print(f"recorded {args.case}/{args.assertion} = {args.result}; case status now {case['status']}; set status {data['status']}")
            return 0
        print(f"FAIL: assertion {args.assertion} not found in case {args.case}")
        return 2
    print(f"FAIL: case {args.case} not found")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
