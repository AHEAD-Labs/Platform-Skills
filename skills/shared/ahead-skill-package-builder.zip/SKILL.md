---
name: ahead-skill-package-builder
description: Builds and reviews production-ready AI skill packages for Claude and Glean using a Spec-Driven Development lifecycle. Invoke when a user wants to create, structure, standardize, review, test, or submit a Claude skill, Glean Skill, Glean Agent, or cross-platform skill package. Enforce explicit specifications, platform mappings, guardrails, evaluation evidence, resource integrity, and publication readiness; do not replace platform-specific approval or security review.
version: 1.4.0
owner: grace.gallagher@ahead.com
team: Enterprise AI
approved-by: AHEAD eTech team (org-wide skill review); Grace Gallagher (Enterprise AI, owner)
approved-date: 2026-09-17
ahead-platform: [Claude, Glean]
sensitivity: Internal
publication-status: Approved
---

# AHEAD Skill Package Builder

## Spec Summary

### Purpose
Create maintainable, testable, and governable AI skill packages for Claude and Glean by applying Spec-Driven Development (SDD): define the contract first, author the platform implementation second, test against the contract, then submit through the appropriate review path. The package must be usable by another builder without relying on undocumented assumptions or hidden local context.

### Trigger conditions

Use this skill when the user asks to:

- create, design, standardize, document, review, or submit a Claude skill;
- create a Glean Skill, Glean Agent, workflow, agent package, or agent build specification;
- turn a business process into a reusable AI skill;
- create a `SKILL.md`, `SPEC.md`, skill package, agent definition, evaluation set, or pre-submission checklist;
- compare an existing skill to a standard, checklist, testing guide, or production packet;
- migrate or provide parity between a Claude implementation and a Glean implementation.

Do not trigger for a one-off answer, a normal prompt rewrite, a business workflow that is not being made reusable, or implementation work whose primary deliverable is application code rather than a skill or agent package.

### Inputs

| Input | Format | Required? | Notes |
|---|---|---:|---|
| Skill objective | User text or brief | Yes | State the user outcome and business problem. |
| Target platform | Claude, Glean, or both | Yes | Ask only if the choice changes the architecture materially. |
| Example inputs | Files, records, prompts, or sample payloads | Usually | Identify format, provenance, sensitivity, and representative coverage. |
| Output contract | File, structured response, action, or artifact | Yes | Define exact type, naming, required sections, and delivery behavior. |
| Constraints | Brand, policy, security, latency, cost, or approval rules | No | Convert material constraints into acceptance criteria. |
| Existing assets | Skill packets, templates, scripts, schemas, or standards | No | Inspect and reuse authoritative assets; do not paraphrase fixed language. |

If a required input is missing, write a spec with `[NEEDS INPUT: ...]` markers, identify the impact, and stop before authoring a production implementation when the missing input affects safety, permissions, contract structure, or irreversible actions. Do not invent values.

### Outputs

A complete invocation produces a package or review result containing, as applicable:

- a completed `SPEC.md` or equivalent spec summary;
- a Claude `SKILL.md` with required frontmatter and ordered body sections;
- a Glean build specification that identifies agent/skill mode, trigger fields, workflow graph, memory, tools, action contracts, identities, and output validation;
- bundled references, templates, scripts, schemas, and resource-loading instructions;
- `evals/evals.json` with realistic prompts and binary assertions;
- a comparison or traceability matrix showing how requirements map to implementation and tests;
- a release checklist with ownership, sensitivity, approval state, version, and known open items.

### Non-goals

This skill does not:

- grant approval, publish to an organization folder, or bypass manager, eTech, security, legal, or client review;
- invent business rules, quantities, legal language, credentials, permissions, client data, or success metrics;
- turn an unvalidated prototype into a production claim;
- replace platform documentation, a security threat model, a data-classification decision, or an operational runbook;
- build unrelated application code except small deterministic helpers required by the skill package;
- guarantee behavioral parity when Claude and Glean have different tool, memory, action, or artifact capabilities.

## When to Use This Skill

Use this skill for a reusable capability, not for a single conversational response. Start by deciding whether the deliverable is:

1. **Claude skill** — reusable instructions plus on-demand resources and optional deterministic helpers.
2. **Glean Skill** — reusable instructions/resources for Glean's skill surface.
3. **Glean Agent** — a triggerable workflow with explicit steps, tools, memory, permissions, and actions.
4. **Paired package** — shared SDD contract plus platform-specific Claude and Glean adapters.

For deterministic extraction, production artifacts, record writes, or strict output contracts, prefer a deterministic Glean Workflow design and a validator. For open-ended research, analysis, or drafting, an autonomous/Auto prototype may be appropriate, but harden the production path when reproducibility, permissions, or downstream automation matters.

## Inputs

Before drafting, inspect the supplied standards, existing skill packet, templates, scripts, and examples. Treat the most authoritative source as the contract owner for each rule:

- business and policy requirements for what must be true;
- approved templates or standard-language assets for fixed wording and layout;
- platform documentation for current runtime syntax and capabilities;
- validators and harnesses for executable acceptance criteria;
- the user's examples for the target experience, not for unverified facts.

Classify each input as required, optional, or unknown. Record provenance and sensitivity in the spec. Never silently convert an unknown into a default when it could become a user-visible, contractual, security, or operational commitment.

## Instructions

### 1. Scope and classify the capability

Write a one-sentence job statement: **Given [inputs], produce [output] for [user] under [constraints].** Then classify the capability as a skill, agent, paired package, or out of scope. Record at least three explicit non-goals and the correct response for out-of-scope requests.

Decide whether the output is advisory, user-reviewed, client-facing, or irreversible. Require human review before high-stakes or irreversible output. Add a kill switch, bounded execution rule, and escalation path for production capabilities.

### 2. Write the SDD contract before instructions

Create `SPEC.md` using `references/sdd-spec-template.md`. Complete these sections before authoring platform instructions:

- purpose and user outcome;
- trigger and non-trigger conditions;
- input contract, formats, provenance, sensitivity, and missing-input behavior;
- output contract, naming, structure, delivery, and failure behavior;
- non-goals and out-of-scope handling;
- workflow/decision graph and platform choice;
- safety, privacy, permission, and human-review requirements;
- measurable acceptance criteria and golden examples;
- ownership, version, dependencies, approvals, and open items.

The spec is the source of truth. If implementation and spec conflict, update the spec first, then re-derive instructions and tests.

### 3. Design the shared behavior and platform adapters

Define the shared contract once, then map it to each platform.

**Claude adapter:**

- use lowercase kebab-case naming and a specific, trigger-oriented single-line description;
- include the required AHEAD frontmatter and ordered body sections;
- keep instructions imperative and explain why important constraints exist;
- reference bundled resources by path and load them only when needed;
- use deterministic scripts for file generation, parsing, validation, and other repeatable work;
- never tell the runtime to read a repository file that is not bundled or available in its execution context;
- preserve output artifacts as files when the contract requires a file, rather than emitting only chat prose.

**Glean adapter:**

- choose Skill versus Agent explicitly; for an Agent, define trigger, inputs, steps, tools, memory, identities, action contracts, output, and review gates;
- use exact trigger field names and explicit `[[Field Name]]` references for inputs or specific prior outputs where the platform requires them;
- map inputs into sub-agents explicitly; do not assume a sub-agent sees the parent trigger automatically;
- use the narrowest memory scope that preserves correctness and reduce fragile step handoffs;
- allow-list tools and actions, apply least privilege, and put human confirmation before irreversible writes or high-stakes delivery;
- use flat action inputs when the endpoint will receive model-generated content, then validate and parse server-side;
- make JSON-emitting steps fence-hardened and schema-validating; place terminal actions after the user-visible reviewed response when both exist;
- document whether the design is Auto or Workflow and why; production extraction and artifact-generation paths need deterministic validation.

Do not invent undocumented Glean export keys or action wiring. Mark platform details requiring live verification and attach the source or export used for confirmation.

### 4. Separate policy, content, and execution

Keep these concerns distinct:

- **Policy:** guardrails, non-goals, permissions, sensitivity, review, and refusal behavior.
- **Content:** user-provided or retrieved facts, structured payloads, approved standard language, and templates.
- **Execution:** search, parsing, generation, action calls, file writes, validators, and telemetry.

For fixed or approved language, inject from a versioned resource rather than asking the model to retype or paraphrase it. For generated files, build from the approved template, write unknowns to a sidecar/open-items record when appropriate, and keep internal notes out of client-facing output.

### 5. Define quality gates before testing

For each acceptance criterion, define a binary assertion and the evidence that will prove it. Include gates for:

- trigger precision and non-trigger behavior;
- required inputs, missing-input handling, and provenance;
- output type, naming, schema, required sections, and artifact integrity;
- grounding and no-invention behavior;
- policy, privacy, PII, prompt-injection, and permission controls;
- validator/harness results and rendered artifact inspection when files are generated;
- reproducibility, bounded execution, cost/latency limits, and failure recovery;
- version, owner, sensitivity, approval state, and rollback/runbook readiness.

### 6. Test against realistic golden examples

Create at least:

- two happy-path prompts with complete, realistic inputs;
- one edge case with incomplete, unusual, conflicting, or boundary inputs;
- one non-trigger prompt that is adjacent but out of scope;
- additional platform-parity, security, validator, and regression cases whenever the capability has multiple adapters or a material side effect.

Follow `references/testing-guide.md`. Every assertion must be binary, specific, traceable to the spec, and accompanied by evidence. Do not mark a test passed because the response “looks good.” If a test fails, revise the spec or implementation and rerun it; never weaken an assertion only to make the score pass.

### 7. Assemble and review the package

Assemble only files that are referenced and needed:

```text
<skill-slug>/
├── SKILL.md
├── SPEC.md
├── references/
├── evals/evals.json
├── assets/              # templates or approved standard-language resources
└── scripts/             # deterministic helpers and validators
```

Run a resource-integrity check: every referenced file exists, every required field is present, schemas parse, scripts have a bounded failure mode, and no secret or real client data is embedded. For a file-producing skill, run the real builder and validate the generated file, not just the input JSON or draft text. Ship that check as its own validator script inside the package — stdlib-only, deterministic, and fail-closed, following the pattern in `scripts/validate_package.py` — and record who inspected the rendered output.

### 8. Release with honest status

Set semantic versioning and record the change log. Distinguish **draft**, **pilot**, **approved**, and **published**. Do not represent a draft as approved or a planned test as completed. Include unresolved `[NEEDS INPUT: ...]` items and route approval to the correct owner.

**Install and publication routing:**

- **Install in the user's own Claude or Glean workspace:** the skill owner signs off. Confirm the spec, implementation, and resources are complete, structural checks pass, and evaluation status is honest.
- **Org-wide publication:** owner sign-off is not sufficient. Tell the user to contact the AHEAD eTech team, which runs the separate org-wide skill review process. Never present owner sign-off, a passing validator, or a completed self-review as org-wide approval.
- **This package's own state:** approved by the AHEAD eTech team for org-wide installation on 2026-09-17 at 1.4.0. Org-wide approval covers distribution and install; it does not convert `not_run` runtime evaluations into recorded evidence, so keep evaluation status honest and continue recording runs with `scripts/record_eval_run.py`.

## Output Format

When building a package, return or create the following files as applicable:

1. `SKILL.md` — executable Claude skill instructions with AHEAD frontmatter.
2. `SPEC.md` — completed SDD contract and acceptance criteria.
3. `references/comparison-matrix.md` — source-to-requirement comparison and design decisions.
4. `references/platform-matrix.md` — Claude/Glean mapping and parity notes.
5. `evals/evals.json` — test prompts, expected outputs, assertions, pass state, and evidence.
6. `README.md` or release note — install/use/review instructions, ownership, dependencies, and approval status.
7. `assets/` and `scripts/` — only when required by the contract, each with a short resource description.

For a review-only request, produce a concise findings table with **Requirement, Evidence, Gap, Risk, and Recommendation**, then state whether the package is ready for draft, pilot, or submission review. Do not call it production-ready when required tests, approvals, resources, or validators are missing.

## Quality Checklist

- [ ] The capability has one clear job statement and an explicit platform classification.
- [ ] `SPEC.md` is complete before implementation instructions are finalized.
- [ ] Triggers and non-triggers are concrete and testable.
- [ ] Inputs include format, required/optional status, provenance, sensitivity, and missing-input behavior.
- [ ] Outputs include type, naming, structure, delivery, and failure behavior.
- [ ] At least three non-goals and out-of-scope handling are documented.
- [ ] Claude and Glean adapters share the same contract and identify meaningful differences.
- [ ] Glean mode, step graph, memory, tools, actions, identities, and review gates are explicit.
- [ ] No undocumented platform syntax, guessed values, secrets, or real client data are embedded.
- [ ] Approved templates and standard language are loaded from versioned resources, not paraphrased.
- [ ] Deterministic builders and validators are used where repeatability matters.
- [ ] The package contains two happy-path, one edge-case, and one non-trigger evaluation at minimum.
- [ ] Assertions are binary, traceable, and supported by evidence.
- [ ] Generated artifacts are validated after generation, including rendered inspection when relevant.
- [ ] Resource integrity, security, privacy, bounded execution, observability, versioning, rollback, and approval status are checked.
- [ ] Change log, owner, sensitivity, and publication status are current.

## Limitations

- Platform syntax, model availability, action schemas, rate limits, and governance features can change; verify current platform documentation and a representative export before release.
- This skill creates the design and package but cannot grant organizational approval or confirm a security/legal decision.
- A shared spec does not guarantee byte-for-byte parity between Claude and Glean; compare behavior using the same golden examples.
- A validator can detect defined failure modes but cannot prove the absence of every hallucination or security issue.
- If a required template, standard-language asset, runtime, permission, or validator is unavailable, stop at a clearly labeled draft and document the blocker.

## Change Log

- **1.4.0** — Recorded AHEAD eTech org-wide skill review approval (2026-09-17) and moved publication status from Pilot to Approved for org-wide installation on Claude and Glean. Added this package's own install/publication state to the routing guidance, added an open item to attach the eTech review reference as durable evidence, and preserved honest `not_run` runtime evaluation status.

- **1.2.1** — Corrected owner team metadata to Enterprise AI, aligned SPEC/evaluation versions, and added deterministic package-integrity checks and release-readiness documentation.

- **1.2.0** — Added the five-category soft/hard guardrail model and evaluation coverage.


- **1.1.0** — Restructured the package-builder specification using the AHEAD Service Brief pattern while preserving SDD, platform mapping, governance, testing, integrity, and release requirements.

- **1.0.0** — Initial SDD-based Claude/Glean skill package standard synthesized from the AHEAD skill standard, pre-submission checklist, spec template, testing guide, and AHEAD Service Brief generator production practices. Draft pending eTech review.

## Resources

- `SPEC.md` — this package's completed specification and acceptance criteria.
- `references/comparison-matrix.md` — comparison of the four supplied standards documents against the Service Brief generator packet.
- `references/platform-matrix.md` — shared contract and Claude/Glean implementation mapping.
- `references/sdd-spec-template.md` — canonical AHEAD spec-first template maintained by this skill; build new specs from it instead of inventing a structure.
- `references/testing-guide.md` — canonical AHEAD evaluation and assertion standard maintained by this skill.
- `evals/evals.json` — starter evaluation set for this meta-skill; statuses are honest and must be run in the target runtime before submission.
