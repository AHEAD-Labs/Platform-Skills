# SDD Spec Template

## Skill identity

- Name:
- Version:
- Owner:
- Team:
- Target platform(s):
- Sensitivity:
- Publication state:
- Approver / approval date:

## 1. Purpose and user outcome

**Given:**

**Produce:**

**For:**

**Why:**

## 2. Trigger and non-trigger conditions

### Triggers

- 

### File/context signals

- 

### Does not trigger when

- 

## 3. Inputs

| Input | Format/schema | Required? | Provenance | Sensitivity | Missing-input behavior |
|---|---|---:|---|---|---|
| | | | | | |

## 4. Outputs

- Type:
- Name/pattern:
- Required structure:
- Delivery channel:
- Failure behavior:
- Human review required? Why?

## 5. Non-goals and out-of-scope handling

This capability does not:

- 

When asked for an out-of-scope result, it should:

- 

## 6. Behavior and platform design

- Capability type: Claude skill / Glean Skill / Glean Agent / paired package
- Claude adapter:
- Glean adapter:
- Workflow or decision graph:
- Deterministic steps:
- Reasoning steps:
- Tools/actions and permissions:
- Memory/context policy:
- Identity and confirmation:
- Bounded execution:

## 7. Guardrails and failure modes

| Risk/failure mode | Prevention | Detection | Recovery/escalation |
|---|---|---|---|
| | | | |

## 8. Acceptance criteria

| ID | Criterion | Evidence | Test case |
|---|---|---|---|
| AC-1 | | | |

## 9. Golden examples and eval plan

- Happy path 1:
- Happy path 2:
- Edge case:
- Non-trigger:
- Platform parity cases:
- Security/permission cases:
- Artifact/validator cases:

## 10. Dependencies and resources

- Templates:
- Standard-language files:
- Scripts:
- External tools/actions:
- Current platform references:

## 11. Release and governance

- Versioning rule:
- Owner:
- Sensitivity:
- Required reviews:
- Rollback/deprecation:
- Observability/telemetry:
- Open items:
