# Comparison Matrix

## Executive finding

The supplied AHEAD documents define a strong Claude-oriented governance baseline: spec-first authoring, required frontmatter/body sections, pre-submission checks, minimum evaluations, and submission packaging. The AHEAD Service Brief generator is a stronger production exemplar because it adds executable implementation boundaries, approved-resource handling, guardrails, deterministic building, post-build validation, sidecar open items, measurement, and explicit refusal/routing behavior. The proposed standard preserves the baseline and generalizes those production controls to Claude and Glean.

## Matrix

| Capability | Supplied standards documents | Service Brief generator packet | Proposed cross-platform standard |
|---|---|---|---|
| Lifecycle | Spec → Author → Test → Submit | Read inputs → contract → build → validate → deliver | Spec → Design → Author → Test → Release, with platform adapter mapping |
| Scope control | Purpose, triggers, inputs, outputs, non-goals | Service Brief, SOW guardrail, proposal handoff, ambiguity rule | Explicit capability classification, non-triggers, and out-of-scope routing |
| Output contract | File type, naming, required structure | Finished `.docx`, fixed section order, template-driven output | Exact output contract plus artifact/schema/render validation |
| Unknown values | Missing-input behavior in checklist/template | `[NEEDS INPUT: ...]`, separate open-items sidecar, no invented scope | Provenance, no-invention rule, open-item handling, stop conditions |
| Fixed language | Not specified beyond standards/checklist | Injected from approved `standard_language.json`; do not hand-write | Versioned policy/content resources; model does not paraphrase fixed language |
| Implementation | Required SKILL.md structure | Builder script, stdlib-only fallback, encoded template assets | Separate policy/content/execution; deterministic helpers where repeatability matters |
| Testing | 2 happy, 1 edge, 1 non-trigger; `evals.json` | Preflight, validation checklist, real build checks | Golden examples, binary assertions, runtime/validator/rendered artifact gates |
| Guardrails | Sensitivity, approval, non-goals | Never SOW content; OA routing; client-safe document; baseline provenance | Permission, PII, prompt-injection, irreversible-action, human-review, and routing gates |
| Observability | Not required in supplied docs | Build/redirect/feedback measurement and client-name hashing | Versioned telemetry and privacy-safe measurement where operationally justified |
| Claude support | Directly specified | Existing Claude skill packet | Native Claude package contract and resource-loading rules |
| Glean support | Not specified | No Glean mapping | Explicit Skill vs Agent decision, trigger fields, memory, tool/action contracts, identity, Workflow vs Auto choice |
| Release governance | Folder placement and eTech approval | OA/Solution Lead handoff and review language | Draft/Pilot/Approved/Published states, rollback/runbook readiness, approval evidence |

## Design decisions adopted

1. Retain the five-section AHEAD spec and expand it with provenance, safety, platform, acceptance, and release fields.
2. Retain the required Claude frontmatter/body structure and add a platform adapter section rather than forcing Glean into Claude syntax.
3. Treat the Service Brief generator's builder + validator + sidecar pattern as the minimum bar for deterministic artifact skills.
4. Require platform parity tests when both Claude and Glean implementations are shipped.
5. Treat “approved,” “tested,” and “published” as evidence-backed states, not labels the model may infer.
6. Make current platform behavior a verification task; never embed undocumented Glean export or action keys as if they were stable.
