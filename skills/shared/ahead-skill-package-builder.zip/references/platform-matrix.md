# Platform Mapping: Claude and Glean

## Shared contract

Every implementation starts from the same `SPEC.md`: objective, triggers, inputs, outputs, non-goals, guardrails, acceptance criteria, examples, owner, version, sensitivity, dependencies, and approval state.

## Claude adapter

| Shared concern | Claude implementation |
|---|---|
| Discovery | Single-line, specific frontmatter description with common user language and exclusions. |
| Instructions | Required ordered sections: Spec Summary, When to Use, Inputs, Instructions, Output Format, Quality Checklist, Limitations, Change Log. |
| Resources | Bundled references, templates, assets, and scripts loaded on demand and described in `## Resources`. |
| Determinism | Use scripts for file creation, parsing, validation, and other repeatable work. |
| Delivery | Create the required file/artifact; do not substitute chat prose when the contract requires a file. |
| Testing | Run exact prompts and record binary assertions/evidence in `evals/evals.json`. |

## Glean Skill adapter

Use when the capability is reusable instructions/resources and does not need a triggerable multi-step workflow. Define the same description, inputs, outputs, resources, guardrails, and evaluations. Confirm the current Glean Skill import/runtime contract before release.

## Glean Agent adapter

Use when the capability needs triggers, retrieval, analysis, sub-agents, custom actions, scheduled runs, or writes. Document:

- trigger type and exact input field names;
- input mapping, including explicit references such as `[[Field Name]]` where supported;
- step graph and deterministic versus reasoning steps;
- tool allow-list and source permissions;
- memory scope per step and context budget;
- sub-agent input/output contracts;
- action schema, authentication, identity, confirmation, and idempotency;
- output schema and validation/repair path;
- stopping conditions, retry limits, cost/latency limits, observability, rollback, and human review.

Choose Auto for exploratory/open-ended work only when variable paths are acceptable. Choose Workflow when the sequence is known, the output is deterministic, the result feeds another system, or the action is high-stakes/irreversible. Verify all current Glean behavior against live documentation or a representative export before implementation.

## Parity rules

- Use identical golden inputs and equivalent assertions for both platforms.
- Compare user-visible outcome, not internal step count or wording.
- Record intentional differences in the spec.
- Do not claim parity when one platform lacks a required tool, action, artifact path, permission model, or validator.
