# Testing Guide for SDD Skill Packages

## Minimum test set

Run at least four cases:

1. Two happy-path prompts with realistic, complete inputs.
2. One edge case with missing, conflicting, unusual, or boundary input.
3. One adjacent non-trigger request.

For paired Claude/Glean packages, run the same golden inputs on both platforms and add tests for intentional differences. For file-producing or action-taking skills, add a real end-to-end build/action test, schema validation, and rendered/record inspection where applicable.

## Assertion rules

Each assertion must be:

- binary: pass or fail;
- specific: names a required behavior or value;
- traceable: maps to a spec requirement;
- evidenced: records what was observed.

Good assertions:

- `Output is saved as a .docx with the required naming pattern.`
- `Generated document contains the six required sections in the specified order.`
- `The skill marks an unknown quantity as [NEEDS INPUT] and does not invent a value.`
- `The Glean workflow does not execute the write action before human confirmation.`
- `The adjacent request does not invoke the skill.`

Bad assertions:

- `Output looks good.`
- `The model followed the instructions.`
- `The answer is high quality.`

## Test result policy

If an assertion fails, revise the spec or implementation and rerun. Do not weaken the assertion solely to make the test pass. If the runtime is unavailable, mark the case `not_run` and label the package Draft or Pilot.

## Extended trigger precision

After the minimum set, run five realistic prompts that should trigger and five adjacent prompts that should not. Tighten or broaden the description based on observed false positives and false negatives.
