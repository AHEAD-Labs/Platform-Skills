# AHEAD Skill Package Builder

## Release state

- **Version:** 1.4.0
- **Owner:** Grace Gallagher, grace.gallagher@ahead.com
- **Team:** Enterprise AI
- **Platforms:** Claude and Glean
- **Sensitivity:** Internal
- **Publication status:** Approved — cleared by the AHEAD eTech team for org-wide installation on Claude and Glean
- **Approval:** AHEAD eTech team, org-wide skill review, 2026-09-17 (recorded by the owner from the approval notice; reviewer/reference to be attached as durable evidence). Prior eTech contract and adapter review completed 2026-09-11 by Grace Gallagher (Enterprise AI, eTech reviewer).
- **Outstanding:** runtime evaluation cases are still `not_run`, so `--release-gate` intentionally continues to report the evidence requirement.

This package defines a spec-first lifecycle for creating, reviewing, testing, and preparing reusable Claude and Glean skill packages. It does not grant approval, publish packages, or replace platform, security, privacy, legal, or operational review.

## Package contents

- `SKILL.md` — executable skill instructions.
- `SPEC.md` — source-of-truth contract, guardrails, acceptance criteria, rollout, and open items.
- `references/` — comparison, platform mapping, spec template, and testing guidance.
- `evals/evals.json` — minimum golden, guardrail, parity, security, integrity, and artifact-validation cases.
- `scripts/validate_package.py` — stdlib-only structural and release-gate validator.
- `scripts/record_eval_run.py` — evidence-enforcing recorder for runtime evaluation results.

## Install

Org-wide installation is approved at 1.4.0. The package is platform-agnostic; the same files install on both surfaces.

**Glean (org-wide):** publish this directory as the org skill `ahead-skill-package-builder`, replacing 1.3.0. Keep the folder structure intact so `references/`, `evals/`, and `scripts/` resolve, and confirm the org skill description matches the `SKILL.md` frontmatter description so trigger precision is preserved.

**Claude:** install the distributed archive `ahead-skill-package-builder-1.4.0.zip` as a skill. Unzip it so `SKILL.md` sits at the root of the skill folder with `SPEC.md`, `README.md`, `references/`, `evals/`, and `scripts/` alongside it.

After install on either platform, run the structural check from the skill directory and confirm `RESULT: PASS`.

## Verification

Run from this directory:

```bash
python3 scripts/validate_package.py
```

The structural check must pass before distribution. It verifies metadata alignment, required resources, reference integrity, JSON/evaluation schema, minimum coverage, deprecated team terminology, and high-confidence secret literals.

Install readiness for a Claude or Glean workspace:

```bash
python3 scripts/validate_package.py --install-gate
```

The fully evidenced release gate remains fail-closed until runtime evidence is recorded:

```bash
python3 scripts/validate_package.py --release-gate
```

A passing structural check is not evidence of runtime behavior, visual artifact quality, security approval, or organizational approval. Org-wide approval likewise is not runtime evidence: run the evaluation cases in representative Claude and Glean environments and record evidence in `evals/evals.json`.

## Running the runtime evaluations

The runtime cases must be executed by a person in the target runtime; no local script can execute them. For each case in `evals/evals.json`:

1. Open a **new, clean** Claude or Glean session with only this package loaded, so prior conversation context cannot influence the result.
2. Paste the case `prompt` exactly and attach any `input_files` as sanitized synthetic fixtures. Never use real client data.
3. Judge each assertion independently as pass or fail against the observed output, not against intent.
4. Save the transcript or generated artifact to a durable evidence location.
5. Record the result, which requires a runtime, a recorder, and dated evidence:

```bash
python3 scripts/record_eval_run.py --case 1 --assertion 1-1 --result pass \
  --runtime Claude --run-by you@ahead.com \
  --evidence "Claude run 2026-09-18; transcript <evidence location> lines 12-88"
```

Case and set status are recomputed from the recorded assertions; they cannot be set by hand. Check progress and evidence quality with:

```bash
python3 scripts/record_eval_run.py --show
python3 scripts/record_eval_run.py --verify
```

Cases 1 and 2 are single-platform. Cases 3, 4, G-01, G-02, G-03, R-01, S-01, and A-01 run on both platforms. P-01 requires the same golden input on both platforms and compares the user-visible contract and safety behavior, not identical wording.

## Install decision

This package is **approved for org-wide installation** on Claude and Glean as of 2026-09-17 at 1.4.0, per the AHEAD eTech org-wide skill review recorded in the `SPEC.md` review log. Distribution and install no longer require per-user owner sign-off.

Two items remain open and are tracked in `SPEC.md` Section 12: attaching the eTech review reference as durable approval evidence, and executing the runtime evaluation cases with dated per-assertion evidence. Until the second item is complete, keep evaluation status `not_run`, do not describe the package as runtime-validated, and expect `--release-gate` to report the evidence requirement. Roll back to 1.3.0 by restoring the prior package version if a defect is found after distribution; the owner holds telemetry, evidence, and rollback records.
