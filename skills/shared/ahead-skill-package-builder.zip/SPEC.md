# SPEC — AHEAD Skill Package Builder

Spec-driven: this document is the contract. Changes to `SKILL.md`, references, scripts, package templates, or evaluation guidance must trace to a requirement here, and the acceptance criteria are the gate.

- **Version:** 1.4.0
- **Owner:** Grace Gallagher, grace.gallagher@ahead.com
- **Team:** Enterprise AI
- **Target platforms:** Claude and Glean
- **Sensitivity:** Internal
- **Status:** Approved for org-wide installation (Claude and Glean)
- **Approval:** Org-wide skill review approved by the AHEAD eTech team, 2026-09-17, at 1.4.0. Earlier eTech review of the contract and adapters completed 2026-09-11. Runtime evaluation evidence is still `not_run` and is tracked as an open item; the fail-closed `--release-gate` therefore continues to report the evidence requirement.

### Review log

| Date | Reviewer | Scope reviewed | Result |
| --- | --- | --- | --- |
| 2026-09-11 | Grace Gallagher (Enterprise AI, eTech reviewer) | Spec contract, Claude and Glean adapters, guardrail modes, references, package validator | Reviewed and cleared for Pilot at 1.2.1. Approved/Published state withheld pending runtime evaluation evidence. |
| 2026-09-11 | Grace Gallagher (Enterprise AI, owner) | All five open items: target platforms, telemetry/evidence/rollback ownership, approval path, output-validator interface, canonical standards | Resolved by owner. 1.3.0 adds install/publication routing behavior, AC-18, AC-19, case G-03, and an install gate; these contract additions are covered by case G-03, which is not yet run. |
| 2026-09-17 | AHEAD eTech team (org-wide skill review) | Package contract, Claude and Glean adapters, guardrails, references, validators, release state | Approved for org-wide installation at 1.4.0. Recorded by Grace Gallagher (owner) from the eTech approval notice; the reviewer name and review reference are to be attached as durable evidence (open item). Approval does not substitute for runtime evaluation evidence. |

## 1. Problem

Skill and agent packages can become prompt-first prototypes that lack a durable contract, explicit platform mapping, executable acceptance tests, resource integrity checks, security boundaries, or honest release status. That makes them difficult for another builder to maintain, difficult to compare across Claude and Glean, and easy to misrepresent as production-ready before the required evidence and approvals exist.

The package-builder capability needs a repeatable specification pattern that starts with the business problem, defines the job and user outcome, translates requirements into testable behavior, separates policy/content/execution, and creates a governed path from draft to pilot to approval.

## 2. Purpose and job statement

**Purpose:** Help AHEAD builders create, review, test, standardize, and prepare reusable Claude and Glean skill packages using Spec-Driven Development.

**Job statement:** Given a skill objective, target platform, representative inputs, output contract, constraints, existing assets, and approval context, produce a maintainable skill package or review result whose specification, implementation, evaluations, resources, platform mappings, and release status are explicit, traceable, and honest.

## 3. Goals

- **G1 — Contract first:** Complete the specification before finalizing platform instructions or implementation.
- **G2 — Reusable package:** Produce the required skill, agent, evaluation, reference, asset, script, and release files only when they are needed by the contract.
- **G3 — Platform clarity:** Explicitly map shared behavior to Claude and/or Glean, including meaningful differences and live-verification items.
- **G4 — Governed execution:** Define permissions, privacy, prompt-injection handling, human review, bounded execution, failure recovery, and escalation paths.
- **G5 — Evidence-based quality:** Use binary acceptance criteria, realistic golden examples, deterministic validators, and generated-artifact inspection where applicable.
- **G6 — Resource integrity:** Ensure every referenced resource exists, every schema parses, scripts have bounded failure behavior, and no secrets or real client data are embedded.
- **G7 — Honest release:** Distinguish Draft, Pilot, Approved, and Published; never represent planned work or incomplete review as completed.
- **G8 — Builder usability:** Make the package usable by another builder without undocumented assumptions or hidden local context.

## 4. Non-goals

- Granting organizational approval or publishing to an organization folder.
- Bypassing manager, eTech, security, legal, privacy, client, or platform review.
- Inventing business rules, quantities, legal language, credentials, permissions, client data, or success metrics.
- Turning an unvalidated prototype into a production claim.
- Replacing platform documentation, a security threat model, a data-classification decision, or an operational runbook.
- Building unrelated application code except small deterministic helpers required by the package.
- Guaranteeing byte-for-byte or behavioral parity when Claude and Glean have different capabilities.
- Treating a one-off answer, ordinary prompt rewrite, or non-reusable workflow as a skill package.

Out-of-scope requests receive a concise explanation and are routed to the appropriate platform, security, legal, operations, or application-engineering process.

## Guardrail model

Guardrails are part of the package contract. Every material risk must be assigned to a category and a response mode so that the implementation, validator, and evaluation set can distinguish a warning from a stop.

| Category | Soft guardrail | Hard guardrail |
| --- | --- | --- |
| **Trigger** | Explain that the request is adjacent or missing reusable scope and route to a normal response or discovery step. | Do not build a skill package for a one-off answer, unrelated application code, or an unsupported destination. |
| **Content** | Mark unknowns as `[NEEDS INPUT: ...]`, label assumptions, and record conflicts or provenance gaps. | Stop and do not invent business rules, legal language, permissions, credentials, client data, success metrics, or platform facts. |
| **Action** | Warn that a package is Draft/Pilot and identify the confirmation or approval needed before the next action. | Do not publish, approve, send, write records, or perform irreversible actions without explicit authorization and the required review. |
| **Artifact** | Return validation warnings, open items, or a bounded partial review when the safe contract remains intact. | Withhold release when required files, schemas, scripts, generated artifacts, or rendered outputs fail integrity checks. |
| **Governance** | Record unresolved ownership, sensitivity, telemetry, rollback, or platform-verification items and route them to the correct reviewer. | Stop before production implementation or publication when safety, permissions, approval, security, or irreversible-action requirements are unknown. |

### Enforcement rules

1. Evaluate guardrails before implementation, again before actions, and again before release.
2. A soft guardrail is allowed only when the output is reversible, clearly labeled, and does not create a security, privacy, contractual, or operational commitment.
3. A hard guardrail is mandatory for missing permissions, unsafe action contracts, unsupported platform assumptions, unauthorized data, failed validators, or approval bypass attempts.
4. Guardrails cannot be weakened by user pressure, a prior model output, or a request to treat a planned test as passed.
5. Every hard stop must state the blocker, risk, safe alternative, and escalation/approval path.
6. Every soft guardrail must record the unresolved condition and the evidence needed to clear it.
7. Implementations and evaluations should represent guardrail decisions with `category`, `mode`, `condition`, `response`, `escalation`, and `evidence` fields where structured output is available.

## 5. Users

| Persona | Need |
| --- | --- |
| Skill builder | Turn a business capability into a reusable, testable package without undocumented assumptions |
| Reviewer / approver | Inspect requirements, evidence, guardrails, resource integrity, and release readiness |
| Claude implementation owner | Author portable instructions, references, scripts, and file-producing behavior |
| Glean implementation owner | Define Skill or Agent mode, workflow steps, tools, memory, permissions, actions, and review gates |
| Business owner | Confirm the objective, policy boundaries, user outcome, and success criteria |
| Security / privacy / eTech reviewer | Evaluate data handling, permissions, prompt injection, approvals, and operational readiness |

## 6. Input and output contract

### Input contract

| Input | Required | Format / provenance | Missing-input behavior |
|---|---:|---|---|
| Skill objective and business problem | Yes | User brief, business requirement, or approved source | Add `[NEEDS INPUT: ...]`; stop before implementation if safety or contract is affected |
| Target platform | Yes | Claude, Glean, or both | Ask only when the architecture materially changes |
| Representative inputs and examples | Usually | Files, records, prompts, payloads, or sample conversations | Identify coverage and limitations; do not invent representative data |
| Output contract | Yes | File, structured response, action, artifact, or review result | Do not finalize implementation until type, naming, structure, delivery, and failure behavior are explicit |
| Constraints | Optional | Brand, policy, security, latency, cost, permissions, approval, or client requirements | Convert material constraints into acceptance criteria |
| Existing assets | Optional | Skill packets, templates, scripts, schemas, standards, validators | Inspect and reuse authoritative assets; record provenance and sensitivity |
| Approval and ownership context | Required for release readiness | Owner, reviewers, sensitivity, publication state | Keep status Draft and list `[NEEDS INPUT: ...]` items |

### Output contract

A complete build produces, as applicable:

- `SPEC.md` — this contract and acceptance criteria.
- Claude `SKILL.md` — required frontmatter and ordered reusable instructions.
- Glean Skill or Agent build specification — mode, trigger, fields, steps, tools, memory, identities, actions, outputs, and review gates.
- `evals/evals.json` — realistic prompts, expected outputs, binary assertions, status, and evidence.
- `references/` — platform, testing, comparison, or source guidance needed by the package.
- `assets/` — templates or approved fixed-language resources required by the contract.
- `scripts/` — deterministic builders, parsers, validators, or bounded helpers required by the contract.
- `README.md` or release note — install/use/review instructions, owner, dependencies, approval state, open items, and rollback/runbook notes.

### Failure behavior

- Missing required input: write `[NEEDS INPUT: ...]`, identify impact, and stop before production implementation when the gap affects safety, permissions, contract structure, or irreversible actions.
- Missing reference, template, runtime, permission, validator, or platform capability: stop at Draft or Pilot and document the blocker; do not simulate completion.
- Conflicting specification and implementation: update the spec first, then re-derive instructions and tests.
- Failed evaluation or validator: revise the spec or implementation and rerun; never weaken the assertion solely to improve the score.
- Review-only request: produce findings with Requirement, Evidence, Gap, Risk, and Recommendation; do not call the package production-ready when required evidence is missing.

## 7. Functional requirements

| ID | Requirement | Source / rationale |
|---|---|---|
| FR-1 | Classify the requested capability as Claude Skill, Glean Skill, Glean Agent, paired package, or out of scope. | Architecture choice |
| FR-2 | Write a one-sentence job statement in the `Given [inputs], produce [output] for [user] under [constraints]` form. | Contract clarity |
| FR-3 | Define purpose, goals, user outcome, triggers, non-triggers, inputs, outputs, non-goals, failure behavior, and open items before final implementation. | Spec completeness |
| FR-4 | Define input formats, required/optional status, provenance, sensitivity, and missing-input behavior. | Grounding and governance |
| FR-5 | Define output type, naming, structure, delivery behavior, and failure behavior. | Artifact and interface contract |
| FR-6 | Map shared behavior to Claude and/or Glean without inventing platform syntax, export keys, action schemas, or capabilities. | Platform integrity |
| FR-7 | For Claude, require lowercase kebab-case naming, single-line trigger description, AHEAD frontmatter, imperative instructions, bundled resource paths, deterministic helpers, and file artifacts when required. | Claude adapter |
| FR-8 | For Glean, explicitly define Skill versus Agent, trigger fields, workflow graph, inputs, steps, tools, memory, identities, action contracts, output validation, review gates, and live-verification items. | Glean adapter |
| FR-9 | Map parent trigger inputs explicitly into sub-agents; never assume inherited context. | Workflow reliability |
| FR-10 | Separate policy, content, and execution in the specification and implementation. | Maintainability and safety |
| FR-11 | Require least-privilege tools/actions, narrow memory scope, prompt-injection handling, privacy/PII controls, human confirmation before irreversible actions, bounded execution, and escalation. | Governance |
| FR-12 | Use versioned resources for fixed or approved language and templates; do not ask the model to retype or paraphrase controlled content. | Determinism |
| FR-13 | Define binary acceptance criteria and evidence for trigger precision, inputs, outputs, grounding, policy, validators, reproducibility, observability, versioning, rollback, and approval. | Quality gates |
| FR-14 | Include at least two happy-path, one edge-case, and one non-trigger evaluation; add parity, security, validator, and regression cases when material. | Test coverage |
| FR-15 | Run resource-integrity checks for required files, referenced resources, schemas, scripts, secrets, and real client data. | Package integrity |
| FR-16 | For file-producing skills, execute the real builder and validate the generated artifact, including rendered inspection when relevant. | Artifact integrity |
| FR-17 | Record owner, version, sensitivity, publication state, dependencies, approval evidence, change log, known open items, and rollback/runbook readiness. | Release governance |
| FR-18 | Distinguish Draft, Pilot, Approved, and Published; preserve `not_run` or equivalent status for planned evaluations. | Honest status |

## 8. Non-functional requirements

- **NFR-1 Portability:** Use portable skill conventions and avoid undocumented runtime-specific assumptions.
- **NFR-2 Progressive disclosure:** Keep descriptions concise and load references, templates, scripts, and testing guidance only when needed.
- **NFR-3 Determinism:** Use scripts and validators for repeatable parsing, file generation, schema validation, and artifact checks.
- **NFR-4 Bounded execution:** Bound questions, searches, loops, action calls, cost/latency where known, and failure recovery; document unknown limits rather than inventing them.
- **NFR-5 No silent failure:** Never deliver an invalid artifact or represent an incomplete test, approval, or security decision as complete.
- **NFR-6 Traceability:** Every requirement must map to implementation evidence and at least one binary assertion where testable.
- **NFR-7 Least privilege:** Allow-list tools and actions, use narrow memory scope, and require human confirmation for high-stakes or irreversible actions.
- **NFR-8 Privacy:** Do not embed secrets, real client data, or unauthorized source content; record sensitivity and access assumptions.
- **NFR-9 Maintainability:** Keep policy, content, execution, platform adapters, references, and validators separable so updates can be made without hidden coupling.
- **NFR-10 Operational readiness:** Record telemetry, rollback, escalation, incident handling, and ownership requirements for production-bound packages.

## 9. Acceptance criteria

- **AC-1 Scope:** The package identifies one clear job statement, capability classification, user outcome, and at least three non-goals.
- **AC-2 Trigger behavior:** Triggers and non-triggers are concrete, testable, and aligned with the description and body instructions.
- **AC-3 Input contract:** Inputs include format, required/optional status, provenance, sensitivity, and missing-input behavior.
- **AC-4 Output contract:** Outputs include type, naming, structure, delivery behavior, validation, and failure behavior.
- **AC-5 Platform mapping:** Claude and Glean adapters share the contract and identify meaningful differences without undocumented syntax or guessed values.
- **AC-6 Glean design:** Any Glean Agent design explicitly defines mode, graph, fields, steps, tools, memory, identities, actions, output validation, and review gates.
- **AC-7 Safety:** The package defines prompt-injection, privacy/PII, permission, human-review, irreversible-action, and escalation controls.
- **AC-8 Resource integrity:** Every referenced file exists, schemas parse, scripts have bounded failure behavior, and no secret or real client data is embedded.
- **AC-9 Evaluation coverage:** The package contains two happy-path, one edge-case, and one non-trigger case at minimum, with binary assertions and honest statuses.
- **AC-10 Artifact validation:** File-producing packages run the real builder and validate the generated file, including rendering checks where relevant.
- **AC-11 Traceability:** Requirements map to implementation sections and evaluation evidence; gaps are recorded as open items.
- **AC-12 Release honesty:** Owner, version, sensitivity, approval state, dependencies, rollback/runbook readiness, and change log are current; Draft/Pilot is not represented as Approved/Published.
- **AC-13 Review readiness:** A review-only result uses Requirement, Evidence, Gap, Risk, and Recommendation and does not overstate readiness.
- **AC-14 Guardrail classification:** Each material risk maps to one guardrail category and a soft or hard response mode.
- **AC-15 Hard-stop behavior:** Missing permissions, unsafe action contracts, unauthorized data, failed validators, unsupported platform assumptions, or approval bypass attempts stop the run and provide an escalation path.
- **AC-16 Soft-guardrail behavior:** Non-critical missing information or unresolved context produces labeled open items and evidence requirements without creating an unsafe commitment.
- **AC-18 Install and publication routing:** The package states that owner sign-off covers install in the owner's own Claude or Glean workspace and that org-wide publication requires eTech review; owner sign-off is never presented as org-wide approval.
- **AC-19 Output validator packaging:** A file-producing package ships a deterministic, fail-closed output validator that runs against the generated file, with recorded rendered-inspection evidence where relevant.
- **AC-17 Guardrail evidence:** Evaluation cases exercise trigger, content, action, artifact, and governance guardrails with binary assertions and recorded evidence.

## 10. Test harness

Golden examples to run before a pilot or submission review:

| # | Golden example | Criteria | Status |
|---|---|---|---|
| 1 | **New Claude skill package** — complete objective, platform, examples, output contract, constraints, and approved assets | AC-1 through AC-5, AC-8, AC-9 | Not run in target runtime |
| 2 | **New Glean Agent package** — explicit trigger fields, workflow steps, tools, memory, actions, output validation, and review gate | AC-5 through AC-7, AC-11 | Not run in target runtime |
| 3 | **Incomplete safety-critical input** — missing permission model or irreversible action contract | AC-1, AC-3, AC-7, AC-12 | Not run in target runtime |
| 4 | **Adjacent non-trigger** — one-off prompt rewrite or ordinary factual answer | AC-2, AC-13 | Not run in target runtime |
| 5 | **Resource-integrity regression** — referenced file missing, malformed JSON, or script with unbounded failure behavior | AC-8, AC-10 | Not run in target runtime |
| 6 | **Platform parity** — same golden prompts run through Claude and Glean adapters | AC-5, AC-6, AC-11 | Requires live platform runs |
| 7 | **Security regression** — source contains prompt injection, unauthorized data request, or hidden-instruction disclosure attempt | AC-7, AC-8 | Requires security-focused runtime test |
| 8 | **File-producing package** — real builder runs and generated artifact is validated and rendered | AC-10 | Requires configured builder and renderer |

Record runtime results with `scripts/record_eval_run.py`, which requires a runtime, a recorder identity, and dated evidence for every pass, and recomputes case and set status from the recorded assertions. Evaluation status must remain `not_run` until the target runtime produces evidence. A passing package-integrity check does not prove runtime behavior, visual quality, security approval, or organizational approval.

## 11. Rollout

1. Complete the specification and traceability mapping.
2. Author or update the platform implementations only after the contract is stable.
3. Run package-integrity and schema checks.
4. Run the golden examples in representative Claude and Glean environments.
5. Run security, privacy, permission, parity, validator, and artifact-rendering checks as applicable.
6. Resolve failures by revising the spec or implementation, then rerun the affected tests.
7. Obtain owner, manager/team lead, eTech, security, legal, or business-owner approvals required by the package risk.
8. Publish only when the package is marked Approved with completed evidence; otherwise release as Draft or Pilot with open items.
9. Maintain a rollback path, versioned change log, owner, and operational handoff.

### Install and publication path

| Destination | Who signs off | Requirements |
| --- | --- | --- |
| The owner's own Claude or Glean workspace | Skill owner | Complete spec and implementation, passing structural checks, resolved open items, honest evaluation status |
| Org-wide / organization folder | eTech team, through its separate org-wide skill review | Everything above, plus recorded runtime evaluation evidence and the eTech org-wide review outcome |

**This package:** the AHEAD eTech team approved org-wide installation on 2026-09-17 at 1.4.0, so the package may be distributed and installed org-wide on Claude and Glean. Runtime evaluation evidence remains outstanding; record it with `scripts/record_eval_run.py` before claiming a fully evidenced release or a passing `--release-gate`.

Packages built with this skill must state this distinction and direct users to the eTech team for org-wide publication. Owner sign-off, a passing validator, or a completed self-review must never be presented as org-wide approval.

## 12. Open items

- **Resolved 2026-09-11 (owner):** Both Claude and Glean are supported target platforms; a package built with this skill carries a working implementation for each unless the owner scopes it to one platform. Platform syntax, action, and permission claims are verified against current platform documentation at build time, and any field that cannot be verified is marked for platform verification inside the affected package.
- **Resolved 2026-09-11 (owner):** Grace Gallagher (Enterprise AI) owns package telemetry, evaluation evidence, and rollback records. Per-assertion evidence locations are recorded in `evals/evals.json` by `scripts/record_eval_run.py`; the durable store for transcripts and generated artifacts is designated by the owner.
- **Resolved 2026-09-11 (owner):** The skill owner signs off for installing a package in that owner's own Claude or Glean workspace. Org-wide publication is outside owner sign-off and goes through the separate eTech org-wide skill review; packages must tell users to contact the eTech team if they want to publish org-wide.
- **Resolved 2026-09-11 (owner):** Each file-producing package ships its own output validator script following this package's validator pattern — stdlib-only, deterministic, fail-closed, and run against the generated file. The package owner inspects the rendered output and records that inspection as evidence.
- **Resolved 2026-09-11 (owner):** `references/sdd-spec-template.md` and `references/testing-guide.md` are the canonical AHEAD standards for skill packages and are maintained by this skill. Changes to them are versioned here and traced to this spec.

- **Open 2026-09-17:** Attach the AHEAD eTech org-wide review reference (reviewer, ticket or notice ID, and dated artifact location) to this review log as durable approval evidence; the current entry is owner-recorded from the approval notice.
- **Open 2026-09-17:** Runtime evaluation cases remain `not_run`. Execute them in representative Claude and Glean environments and record dated per-assertion evidence so `--release-gate` can pass at the current Approved status.

## 13. Build architecture

The package builder separates three concerns:

| Layer | Contents | Control |
|---|---|---|
| Policy | Scope, non-goals, permissions, privacy, safety, human review, refusal, approval, release state | `SPEC.md`, `SKILL.md`, platform governance |
| Content | Business objective, user outcome, source facts, approved language, templates, schemas, examples | User inputs and versioned resources |
| Execution | Search, parsing, generation, actions, file writes, validators, telemetry, rollback, review | Platform adapters and deterministic scripts |

### Shared SDD workflow

```text
Classify capability → define problem, purpose, job, goals, users, and non-goals
        ↓
Define inputs/outputs → requirements → non-functional constraints → safety gates
        ↓
Write platform adapters → assemble the reference, script, and asset resources → build evaluations
        ↓
Run integrity and runtime tests → inspect artifacts → record evidence and open items
        ↓
Release as Draft/Pilot/Approved/Published with owner, approvals, rollback, and change log
```

### Claude adapter

Use lowercase kebab-case naming and a specific, trigger-oriented single-line description. Include AHEAD frontmatter and ordered imperative instructions. Reference only bundled or runtime-available resources. Use deterministic helpers for repeatable work and preserve file artifacts when the output contract requires them.

### Glean adapter

Choose Skill versus Agent explicitly. For an Agent, define trigger, inputs, steps, tools, memory, identities, action contracts, output, validation, and review gates. Pass inputs explicitly into sub-agents, use narrow memory, allow-list tools/actions, validate JSON-emitting steps, and place terminal actions after the reviewed response where both exist. Mark undocumented fields and action wiring for live verification.

## 14. Packaging and portability

The expected package shape is:

```text
<skill-slug>/
├── SKILL.md
├── SPEC.md
├── references/
├── evals/evals.json
├── assets/              # only when required
└── scripts/             # only when required
```

Packaging requirements:

- `SKILL.md` has valid frontmatter and a single-line description.
- `SPEC.md` is the source-of-truth contract.
- Every referenced file exists and every required field is present.
- JSON, schemas, and configuration parse successfully.
- Scripts have bounded failure behavior and no hidden dependency on unavailable files.
- No secrets, credentials, real client data, or unauthorized content are embedded.
- Platform-specific fields are verified or marked `[NEEDS INPUT]` / `[NEEDS PLATFORM VERIFICATION]`.
- The package declares its owner, version, sensitivity, approval state, dependencies, evaluation status, and change log.

## 15. Traceability

- AHEAD Skill Package Builder `SKILL.md` — trigger conditions, inputs, outputs, SDD lifecycle, platform adapters, governance controls, quality gates, and release requirements.
- `references/sdd-spec-template.md` — canonical AHEAD contract template, maintained by this skill.
- `references/testing-guide.md` — canonical AHEAD evaluation and binary-assertion standard, maintained by this skill.
- AHEAD Service Brief generator specification — adopted structure for problem, purpose/job statement, goals, non-goals, users, requirements, quality gates, rollout, open items, architecture, packaging, and traceability.
- Platform documentation and representative exports — required live sources for current Claude/Glean syntax, actions, permissions, and runtime capabilities.

## 16. Change log

- **1.4.0:** Recorded the AHEAD eTech org-wide skill review approval dated 2026-09-17 and set the release state to Approved for org-wide installation on Claude and Glean. Added the package's own install/publication state to Section 11 and to the Claude adapter routing guidance, opened two evidence items (eTech review reference, runtime evaluation runs), and kept evaluation status `not_run` rather than inferring evidence from approval.

- **1.3.0:** Recorded owner decisions on install and publication routing (owner sign-off for own-workspace install, eTech review for org-wide publication), required file-producing packages to ship their own fail-closed output validator, established the bundled spec template and testing guide as canonical AHEAD standards, added AC-18 and AC-19, added evaluation case G-03, and added an install-readiness gate.

- **1.2.1:** Corrected owner team metadata to Enterprise AI, aligned package versions, and added deterministic package-integrity and release-gate checks.
- **1.2.0:** Added a five-category soft/hard guardrail model, enforcement rules, acceptance criteria, and evaluation coverage.
- **1.1.0:** Restructured the specification using the AHEAD Service Brief pattern while preserving the package-builder’s SDD, platform-adapter, governance, testing, integrity, and release requirements.
- **1.0.0:** Initial SDD-based Claude/Glean skill package standard.
