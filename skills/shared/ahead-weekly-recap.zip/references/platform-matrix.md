# Platform matrix: ahead-weekly-recap v0.3.0

This file is for reviewers. The recap does not need it at run time.

## Shared contract

Both surfaces install the same folder and run the same `SKILL.md`, and both give the recap twice from the same lists: as tables in the chat reply, and as the same page from `assets/recap-template.html`. The contract is `SPEC.md`; the four shared rules are in `references/ahead-shared-rules.md`. It is a chat skill on both: not a Glean Agent, no schedule, no trigger.

## Side by side

| Concern | Glean Assistant | Claude chat |
|---|---|---|
| What gets installed | A personal Skill, uploaded under the same name so it replaces the earlier copy | A custom skill, uploaded as the zip, with the old version removed |
| Routing | Name and description only; most reliable in thinking mode; also `/ahead-weekly-recap` | Name and description only, or asking for it by name |
| The page | An interactive page, shown in a sandboxed frame | An HTML artifact beside the chat |
| When a page isn't possible | A Glean document with the same parts, beside the chat tables | The chat tables alone, since Claude can't make a document without the same file tools |
| Chat tables | In every reply beside the page, as the owner's Sep 28 run showed rendering | In every reply beside the page |
| Fonts | Base64 text in `assets/`, because Glean corrupts binary files. If the fonts can't be embedded, the page uses a system font without errors | The same files; embedding them is easiest where code can run |
| Copy button | Clipboard, then a copy command, then text selection | The same |
| Time zone | Central by default, or the zone the person's own meetings show; the page switch covers everyone else | The same |
| Filling the page | The page is written out in full, with the font placeholders left as they are | A short script fills the template and fonts, so only the data is written; far faster |
| Where the data comes from | Glean's own connectors | The Glean connector only; Microsoft 365 connected directly is not used |
| Handing off | Not applicable | Claude may pass the request to Glean's assistant through the connector, which reports no skills, so that answer is Glean's plain assistant; the log records it |
| Write tools present | Whatever Glean Assistant offers; never used | The Glean connector's write tools and read-write memory tool; never used, set to ask or block for pilot runs |
| Cost | Interactive pages may carry usage-based pricing | No extra cost noted |
| Kill switch | Settings > Skills | Customize > Skills |

## Intentional differences

Glean may be tempted to write its own page, since it can make interactive pages unprompted. `SKILL.md` says to fill the template and change nothing else, and the sign-off runs check that the page is the template.

## Parity

P-1 compares the two surfaces' recaps of the same week on the layout and the status, evidence and On deck rules. Each surface passes on its own evidence; a Claude run is never evidence for Glean, or the reverse.

## Still to verify

Whether each surface shows the filled template as a page with the fonts and Copy working, and whether Claude accepts the 808-character description (SPEC Section 12).
