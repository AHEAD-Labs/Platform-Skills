# Comparison matrix: ahead-weekly-recap v0.3.0

This file is for reviewers; the recap does not need it at run time. It records the checkpoint 1 side-by-side against the kit's golden references, what was adopted and what was kept, and every source the package draws on.

## Sources

| Source | Pin | Use | License |
|---|---|---|---|
| knowledge-work-plugins `enterprise-search/skills/digest` | `da38ec1`, byte-identical to the `1c7187c4` copy used since 0.1.0 | Adapted: weekly mode, grouping by project, unavailable sources | Apache-2.0 |
| knowledge-work-plugins `sales/skills/weekly-wrap` | `da38ec1`, byte-identical to the `1c7187c4` copy | One idea, adapted: what slipped and what's on deck | Apache-2.0 |
| Anthropic internal-comms example skill, `examples/3p-updates.md` | As read on 2026-09-24 | Adapted: the Progress / Plans / Problems format | Apache-2.0 |
| knowledge-work-plugins `stakeholder-update` | `da38ec1` | Ideas only: green, yellow and red meanings, a reason for each color, specific asks | Apache-2.0; no text copied |
| Glean agent-plugins `using-glean-productivity` | `93bf39d` | Ideas only: did, not viewed; cite every claim; how people ask about their week | MIT; no text copied |
| Glean agent-plugins `project-awareness` and `project-handoff` | `93bf39d` | Ideas only: freshness tests, health with a reason, a structured document shape, "use X instead" boundaries | MIT; no text copied |
| Glean agent-plugins `skill-creation-guide`, Anthropic `skill-creator` | `93bf39d`; as installed 2026-09-28 | Ideas only: description patterns, near-miss negatives | MIT; Apache-2.0; no text copied |
| Anthropic `morning` example skill | As installed 2026-09-28 | Ideas only: hand over a page, voice rules, an internal check before delivery | No license file; ideas only |
| AHEAD daily digest page design, v0.2.0 (the kit's `design/`) | Kit of 2026-09-28 | The shared look: CSS variables, header gradient, Poppins, data island, safety rules | AHEAD internal |
| Poppins | The kit's `design/fonts/` | Fonts as base64 text | SIL Open Font License, in `assets/Poppins-OFL.txt` |
| Glean "Weekly work report" template; AHEAD "[Productivity] Weekly Action Tracker" agent; the owner's weekly status report image | Checked 2026-09-24 and 2026-09-25 | Earlier ideas: accomplishments by project; context and a link on every item; a header grid and summary | Ideas only |

## Side-by-side: description

| | v0.2.0 | Golden references | Decision |
|---|---|---|---|
| What the person gets | 984 characters, said "in chat" | Outcome first, then when | Adopted: outcome first, no "in chat" |
| Phrasings | Six, close to our own words | Glean productivity uses how people talk | Adopted: "how did my week go". 0.4.0, owner decision: any mention of the week with a word for a look back |
| Neighbors | A long list, no pointers | "(use X)" pointers | Adopted: each neighbor named, including time off and one specific meeting |
| Delivery mechanics | Window, read-only, chat | Kit rule: none in the description | Adopted: all removed, including the draft's "as a structured page" |
| Push | None | skill-creator: apply even without the obvious word | Adopted: "even without the word recap" |
| Result | | | 0.3.0: 808 characters. 0.4.0: 948 characters, plain YAML |

## Side-by-side: workflow

| Step | v0.2.0 | Golden references | Decision |
|---|---|---|---|
| Window | Past 7 days ending now | Digest: last 7 days | Kept, made exact: 7 days ending today, including today |
| Questions | None | stakeholder-update and handoff ask first | Kept ours: one request, one answer |
| Evidence | Sent, shared, confirmed, decided, closed | Glean productivity: did, not viewed; cite every claim | Adopted: viewing is never evidence; Done needs a link |
| Currency | Anything in the window | project-awareness: freshness test | Adopted: Still open holds only current items |
| Still-open check | One look at the thread | Morning: open the thread once | Kept ours |
| Status | Fixed rules, no reason | stakeholder-update meanings; handoff "color, why" | Adopted a reason line; the page computes status from the fixed rules |
| Internal check | None | Morning: verify before delivery | Adopted, never shown |
| Voice | Plain | Morning: observe and hand over | Adopted |
| Delivery | Chat tables | Morning: a page | Adopted the page, then (0.4.0, owner decision) kept the chat tables beside it |
| After | Stop; follow-ups are new requests | stakeholder-update offers to send | Kept ours: never offers to send |

## Side-by-side: edge cases

| Case | v0.2.0 | Golden references | Decision |
|---|---|---|---|
| A source can't be read | Named; built from the rest | Digest: the same | Kept |
| Nothing readable | Short reply | stakeholder-update asks for facts; morning replaces the page | Adopted: two sentences and an offer to use pasted notes |
| Calendar unreadable | Notice; never free | Same spirit | Kept |
| Quiet week | Quiet, never padded | Morning: one calm line | Kept; ours was already stronger |
| Recurring meetings on deck | Counted in one line | Not covered | Changed (R5): every one named in the folded line |
| No link for a done item | Named or linked | Cite every claim | Changed (R6), with a page safety net |
| Time zone unknown | Calendar's zone | Design reference: UTC with a note and a switch | 0.5.0, owner decision: Central by default with a note, the person's own meetings' zone when shown, and the digest's switch |
| Chat only | The default | Kit R2 | Changed: on request or as a fallback |
| Narration, praise, internal names | Not covered | Morning voice; the Sep 28 Glean run | Changed (R4, R8, R9) |

## Side-by-side: output template

| Part | v0.2.0 | Golden references | Decision |
|---|---|---|---|
| Container | Chat markdown | Morning page; design reference; handoff document | `assets/recap-template.html` |
| Chat reply | The whole recap | The page is the deliverable | 0.3.0: two or three sentences. 0.4.0, owner decision: the tables again, matching the page |
| Header | Name, week, zone, counts | Handoff attribute table | Kept; counts and day span computed by the page |
| Projects | Table | stakeholder-update; handoff | Cards with status, reason and counts |
| Done | Table with evidence | Cite every claim | Links; unlinked items move to Possibly done |
| On deck | Table | Kit R5 | Grouped by date, then the folded line |
| Upward version | On request | stakeholder-update exec update | On the page every time, with Copy; specific asks in Problems |
| Safety | Not applicable | Design reference | Text only, https-only links, no network, `</` escaped |

## Kept as ours

The four shared rules, the honest Checked line, never acting with a clean handoff when asked to act, quiet reported as quiet, the evidence rule, Possibly done, project grouping and fixed status rules.

## Changes from the design reference

- The font slots are plain text islands that the page turns into fonts only when filled with a complete font file. A placeholder left in a CSS font URL logged a console error in testing, and a partly pasted font logged warnings (2026-09-28); the islands and the completeness check avoid both.
- The time zone switch matches the digest page's, adds the viewer's own zone when it isn't listed, and moves meeting times and their days (0.5.0; 0.3.0 and 0.4.0 had none).
- Status colors: green is AHEAD Green; yellow and red are functional colors, since the AHEAD palette has none.
- No "Mark handled" buttons; the only control is Copy.
