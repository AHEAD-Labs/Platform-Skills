# ahead-weekly-recap

Version 0.5.2. Status: Pilot, signed off by the owner and approved for pilot by AHEAD eTech for the Enterprise Skills Launch. Owner: Akbar Aman (akbar.aman@ahead.com), Enterprise AI.

## What it does

Ask Claude chat or Glean Assistant chat about your week and you get the recap twice, laid out the same way: as tables in the chat, and as a page beside it, so you can read it either way. The recap covers the 7 days ending today, including today, unless you name another window, and it reads in about two minutes:

- a header with your name, the dates, and how many projects are on track, need attention or are blocked;
- times in Central Time unless your own meetings show another zone, with a switch on the page for Eastern, Mountain, Pacific, UTC or your own zone;
- a card per project, with its status and one line naming the item behind it;
- what got done, each item linked to its evidence;
- what is possibly done, and what would confirm it;
- what is still open, with whom and when it is due, or that it slipped;
- what is on deck for the next 7 days, with recurring meetings named in one line;
- a Progress / Plans / Problems version with a Copy button, ready to paste upward;
- a Checked line saying what was read and what wasn't.

Colors follow fixed rules the page applies itself. Blocked means a source says so, or something you're waiting on from someone else is overdue. Needs attention means something of yours slipped, or an item is only possibly done. On track means neither.

Every run is built fresh from your mail, calendar, chats and documents, and cites the original items; earlier digests, recaps, briefs and AI summaries, including its own, are never used. It is read-only. The only thing it creates is the recap itself, and it never sends, posts or shares anything. Ask for one form only, such as "just the tables" or "just the page", and you get that one.

## What to ask

Any mention of the week with a word for a look back: recap, overview, summary, review, rundown, roundup, wrap-up, highlights, report or status update. For example "Give me an overview of my week", "Weekly summary", "Wrap up last week" or "How did my week go?". On Glean you can also type `/ahead-weekly-recap`.

It is not for today or catching up after time off (ahead-daily-digest), one specific meeting (ahead-meeting-prep-and-notes), a whole team's week, performance reviews, simple calendar lookups, or sending the update.

## Install on Glean

1. Settings > Skills > Add > Upload a Skill, and choose `ahead-weekly-recap.zip`. Choose Replace, since the name is unchanged.
2. Make sure it is turned on, wait a couple of minutes, open a new chat and type `/` to check it is listed.
3. Use thinking mode when you ask. Use a fresh chat for each run.

## Install on Claude

Your organization needs Skills and code execution turned on, and you need the Glean connector, AHEAD's approved route to your mail, calendar, chats and documents on Claude.

1. Remove the old version, then Customize > Skills > + > Create skill, and upload `ahead-weekly-recap.zip`.
2. For pilot runs, use a fresh chat, keep Microsoft 365 off for that chat, and set the Glean connector's write tools to ask or block.

If Claude rejects the description as too long, `SPEC.md` Section 12 has a 190-character fallback.

## What has been checked

For 0.4.0, an alignment check confirmed the sample's chat tables and page show the same projects, statuses, items and counts. A QA pass on 2026-09-28 fact-checked the sample against its sources and ran 24 edge-case fixtures at two widths; its findings are fixed in 0.3.1 and re-tested. The QA ran in the build chat, so the independent QA chat and the sign-off runs are still worth doing. Structural checks passed on 2026-09-28. The kit's "Before handing off" list passes in full, and the builder's validator passes as an adjusted copy (unchanged, it fails only on checks hardwired to the builder's own package). The page template was rendered in a headless browser at 1100px and 380px with the QA fixtures, with no console errors, safe text, https-only links and a working Copy button. One real sample page from the owner's week was made on the Claude side and traced item by item to its sources. Details are in `SPEC.md` Section 12.

## What has not been checked

No runs on either surface are recorded against the cases yet; both tracks and every case in `evals/evals.json` are `not_run`. Still to confirm on the surfaces: that each shows the filled template as a page with the fonts and Copy working, that Glean keeps the template rather than writing its own page, the routing rows against the other two skills, and the description length on Claude.

## Known limitations

- Interactive pages on Glean may carry usage-based pricing.
- Switching the page's time zone moves meeting times and the days they fall on. Dates written inside item text, such as "Fri Sep 25", stay as written.
- If the fonts can't be embedded, the page uses a system font.
- Teams direct messages appear only if you have turned them on in Glean, and the recap can't always tell when they're missing.
- Work that left no linkable trace shows up as possibly done or not at all.
- On Claude, the assistant may hand the request to Glean's assistant, which runs no skills when reached that way.
- The example internal-comms skill on Claude also writes 3P updates and may answer a request for the upward version.

## Files

| File | What it is |
|---|---|
| `SKILL.md` | The instructions both surfaces run |
| `SPEC.md` | The contract, acceptance criteria, decisions and open items |
| `assets/recap-template.html` | The page template, with its data format in the opening comment |
| `assets/poppins-latin-400-normal.woff2.b64.txt`, `assets/poppins-latin-500-normal.woff2.b64.txt`, `assets/poppins-latin-600-normal.woff2.b64.txt` | Poppins as base64 text |
| `assets/Poppins-OFL.txt` | The font license |
| `references/ahead-shared-rules.md` | The four shared rules, identical in all three skills |
| `references/comparison-matrix.md` | The side-by-side against the golden references, and every source |
| `references/platform-matrix.md` | How Glean and Claude each meet the contract |
| `evals/evals.json` | Test cases, all `not_run` until real runs are reported |
| `LICENSE-APACHE-2.0` | Notice and license for adapted material |

## Provenance

Adapted from two Apache-2.0 skills in anthropics/knowledge-work-plugins (the digest skill in weekly mode, and the "what slipped / on deck" idea from weekly-wrap), cited at `da38ec1` and byte-identical to the earlier `1c7187c4` copies, and from Anthropic's 3P update guide, also Apache-2.0. Ideas only, with no text copied, from stakeholder-update, Glean's agent-plugins references (MIT), the skill-creator guidance and the morning example skill. The page is built on AHEAD's shared page design. Details are in `references/comparison-matrix.md`.

## Change notes

- **2026-09-28, 0.5.2 Glean build.** eTech pilot approval for the Enterprise Skills Launch and Grace Gallagher's rollout release recorded under Approvals, and `SKILL.md`'s `further-approvals` field updated to match. Frontmatter stays flat, as Glean requires; the Claude build instead nests the AHEAD fields under `metadata`. No change to what the skill does.
- **2026-09-28, 0.5.2.** Owner sign-off recorded: `approved-by` is Akbar Aman and `approved-date` is 2026-09-28, and a new `further-approvals` field points to the Approvals table above, with rows for rollout, leadership, eTech and anyone else. No change to what the skill does.
- **2026-09-28, 0.5.1.** Owner rule added to `SKILL.md` as rule 9: earlier digests, recaps, briefs and AI summaries, including this skill's own, are never a source; every run is built fresh and cites the original item. Rules 9 and 10 became 10 and 11, and the internal check gained a matching line. `SPEC.md` (AC-12, a guardrail row) and `evals/evals.json` (case E-11) updated to match. The page template is unchanged.
- **2026-09-28, 0.5.0.** Owner decisions for speed. `SKILL.md`: one pass per source, about five to eight reads for a typical week, checks against what was already read, and a scripted fill where code can run, never typing font data out; Central Time by default, or the zone the person's own scheduled items show, with no separate lookup. `assets/recap-template.html`: a time zone switch like the daily digest's, plus the viewer's own zone, and meeting start times that follow it; the chat's On deck table gains a Time column. `SPEC.md`, `evals/evals.json` (new cases E-9, E-10 and A-2) and both reference matrices updated to match.
- **2026-09-28, 0.4.0.** Owner decisions. The recap comes as tables in chat and as the page, built from the same lists so both show the same items, statuses and counts; this replaces the two or three sentence chat reply. The description now triggers on any mention of the week with a word for a look back (948 characters). `SKILL.md`, `SPEC.md`, `evals/evals.json` (new cases T-3 to T-5), both reference matrices and the page's failure message were updated to match.
- **2026-09-28, 0.3.1.** QA fixes. `SKILL.md`: read what the person sent for promises and asks, check once for a share before calling anything possibly done, list each piece of work once, use a form the person names, and cover only the person's own week when asked about someone else's; two new lines in the internal check. `assets/recap-template.html`: the person's own name or "me" counts as their own item, fonts are used only when the pasted data is a complete file, items with no text are skipped, missing dates and duplicate project ids are handled, and the card counts meet text contrast. `SPEC.md` and `evals/evals.json` gain matching criteria and cases E-6 to E-8. `references/comparison-matrix.md` notes the font check.
- **2026-09-28, 0.3.0.** Built from the owner's v0.3.0 kit (items R1 to R10) and the checkpoint 1 side-by-side (items A1 to A12), approved the same day.
  - `SKILL.md`: new description with named neighbors (the colon after "past week" became ", covering" so it stays a plain YAML line); delivery is a page, then a document, then chat; rule 5 now says the only thing created is the recap; Done needs a link, and viewing is never evidence; Still open holds only current items; exactly 7 days ending today; On deck names every folded meeting; a status reason for every project; a voice rule with no narration, praise words or internal names; an internal check before handing over; an offer to use pasted notes when nothing can be read; the upward version on the page every time.
  - New `assets/recap-template.html` on the shared design, and the three Poppins files and their license, unchanged from the kit. Two changes from the design reference: the font slots are text islands, so an unfilled slot causes no console error, and there is no time zone switch. The page works out every count, each status and reason, slipped items and the day span.
  - `SPEC.md`, `references/comparison-matrix.md`, `references/platform-matrix.md` and `evals/evals.json` rewritten for 0.3.0. `LICENSE-APACHE-2.0`: the notice now cites `da38ec1` and the font license; the standard text is unchanged.
  - Unchanged: `references/ahead-shared-rules.md`.
- **2026-09-24, 0.2.0.** The chat recap laid out as markdown tables with fixed status colors.
- **2026-09-24, 0.1.1.** Flat frontmatter, so Glean would load the skill.
- **2026-09-24, 0.1.0.** First chat recap.

## Governance and open items

This is a pilot, signed off by its owner. Rollout beyond the owner is Grace Gallagher's decision, and org-wide publication also goes through the AHEAD eTech review. A passing validator is not approval.

## Approvals

Each approval names the version it covers. To approve, fill in a row and re-zip; for anyone not listed, add a row.

| Role | Name | Date | Version | Notes |
|---|---|---|---|---|
| Owner sign-off, pilot use | Akbar Aman | 2026-09-28 | 0.5.2 | Signed off before the surface runs in the sign-off sheet |
| Rollout beyond the owner | Grace Gallagher | 2026-09-28 | 0.5.2 | Released for the Enterprise Skills Launch pilot on Glean |
| Leadership | | | | |
| AHEAD eTech review, pilot for the skills launch | AHEAD eTech | 2026-09-28 | 0.5.2 | Pilot approval for the Enterprise Skills Launch, as reported by Grace Gallagher. Attach the eTech approval reference here. Org-wide publication beyond the pilot is still open |
| Other | | | | |

For AHEAD AI tools, policies or governance questions, see the AHEAD AI HIVE or your eTech team contact.

STATUS FOR GRACE
- Package: built
- Owner sign-off: Akbar Aman, 2026-09-28, for pilot use (see Approvals)
- eTech: pilot approval for the Enterprise Skills Launch, 2026-09-28, as reported by Grace Gallagher (see Approvals)
- Validator: pass on the adjusted copy, and every item on the kit's handoff list passes. The builder's validator, run unchanged, fails only on checks hardwired to the builder's own package, as expected.
- Claude real use: sample pages from the owner's own week (Tue Sep 22 to Mon Sep 28), made in the build chat by following `SKILL.md` through the Glean connector. A QA pass fact-checked the 0.3.0 sample, found one wrong fact and two missed items, and the rebuilt 0.3.1 sample checks out. Not a run of the installed skill.
- Glean real use: 0.1.1 and 0.2.0 ran on Glean in the owner's own chats (a recap for "need a overview of my week", and the Sep 28 run in the kit's evidence), which shaped 0.3.0. 0.3.x has not run on Glean.
- Not tested: 0.5.2 on Glean; the page on either surface as the surface shows it; the routing rows against the other two skills; the description length on Claude; the broader trigger against the other two skills; run time against the five to eight read budget.
- Known limitations: Glean pages may carry usage-based pricing; fonts fall back to a system font when they can't be embedded; direct messages depend on a personal Glean setting; work with no linkable trace shows as possibly done or not at all; on Claude, a hand-off to Glean's assistant runs no skills.
- Overlaps with existing skills or agents: the "[Productivity] Weekly Action Tracker" agent and its copies; Glean's built-in memory skill and its weekly-summary workflow; Glean's Weekly work report template; the planned Action Capture & Follow-Up skill; the internal-comms example skill on Claude; ahead-daily-digest, scoped apart on purpose.
- Decisions for Grace: this skill now answers in chat with the full tables beside the page, unlike the other two skills' short chat summary; whether a separate weekly recap is wanted next to the Weekly Action Tracker and the planned Action Capture & Follow-Up skill; whether the usage cost of Glean pages is acceptable at rollout; whether the builder's validator should make its name, file list and case minimums configurable.
- Author's honest read: signed off for pilot use, not yet for rollout. The template and the rules hold up under QA, but 0.5.2 has not run on either surface as the surface shows it, so the sign-off sheet's runs are still worth doing before rollout.
