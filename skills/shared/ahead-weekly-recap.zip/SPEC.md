# SPEC: ahead-weekly-recap

This is the contract for the skill. `SKILL.md`, the page template, the shared rules and the evaluations must trace back to it. If they disagree, this file changes first and the rest is re-derived from it.

## Skill identity

- **Name:** ahead-weekly-recap
- **Version:** 0.5.2
- **Owner:** Akbar Aman, akbar.aman@ahead.com
- **Team:** Enterprise AI
- **Target platforms:** Claude chat and Glean Assistant chat, from one folder
- **Sensitivity:** Internal
- **Publication state:** Pilot
- **Approval:** Signed off by the owner, Akbar Aman, on 2026-09-28 for pilot use, before the surface runs in the sign-off sheet. Further approvals are recorded in the README's Approvals table: rollout beyond the owner is Grace Gallagher's decision, org-wide publication also goes through the AHEAD eTech org-wide skill review, and leadership or anyone else asked to approve gets a row there too.
- **Built with:** ahead-skill-package-builder 1.5.0, from the owner's v0.3.0 kit (build brief items R1 to R10)
- **Shares with:** ahead-daily-digest and ahead-meeting-prep-and-notes, through `references/ahead-shared-rules.md` (v1.0, md5 `328314a998bc`)

| Date | Step | State |
|---|---|---|
| 2026-09-24 | 0.1.0 and 0.1.1 | Chat recap; 0.1.1 moved to flat frontmatter so Glean would load it |
| 2026-09-24 | 0.2.0 | Chat recap as markdown tables |
| 2026-09-28 | 0.3.0, checkpoint 1 | Side-by-side against the kit's golden references and the edit list, approved by the owner with all four proposed decisions |
| 2026-09-28 | 0.3.0, checkpoint 2 | Built and checked (Section 12) |
| 2026-09-28 | 0.5.2 | Owner sign-off recorded (Akbar Aman, pilot use), with an Approvals table in the README for rollout, leadership, eTech and anyone else |
| 2026-09-28 | 0.5.1 | Owner rule: earlier digests, recaps, briefs and AI summaries, including this skill's own, are never a source; every run is built fresh and cites the original item |
| 2026-09-28 | 0.5.0 | Owner decisions for speed: Central Time by default, or the zone the person's own scheduled items show, with a time zone switch on the page; one pass per source, about five to eight reads; the page filled by script where code can run |
| 2026-09-28 | 0.4.0 | Owner decisions: the recap comes as tables in chat and as the page, both from the same lists; and any mention of the week with a word for a look back triggers it |
| 2026-09-28 | 0.3.1, QA pass | QA run in the build chat at the owner's request found one wrong fact and two missed items in the sample, plus five page edge cases; fixed and re-tested (Section 12). Waiting on the owner's sign-off runs |

## Spec Summary

- **Job:** a two-minute recap of the person's own past week that they can keep and paste upward: what got done with evidence, what is possibly done, what is still open and what is coming next week, grouped by project, plus a Progress / Plans / Problems version.
- **Triggers:** any mention of the week together with a word for a look back, such as recap, overview, summary or review, in the person's own words (Section 2).
- **Inputs:** the request, plus read access, as the person, to their own mail, calendar, chats and channels, and documents (Section 3).
- **Output:** the recap twice, matching: as tables in the chat reply, and as a page from `assets/recap-template.html` beside the chat, or a document when a page isn't possible. A form the person names is given alone (Section 4).
- **Hard rules:** the only thing created is the recap; something counts as done only with linked evidence; the four shared rules (Sections 4 and 7).
- **Non-goals:** acting on anything, team rollups, agents and schedules, and the neighbor jobs in Section 2 (Section 5).

## 1. Purpose and user outcome

**Given:** a plain request from an AHEAD employee, and read access, as that person, to their own mail, calendar, chats and channels, and documents.

**Produce:** one structured recap the person can keep and scan in about two minutes, with evidence behind everything counted as done, a status and reason for each project, the week ahead, and a Progress / Plans / Problems version ready to copy.

**For:** any AHEAD employee, in Claude chat or Glean Assistant chat.

**Why:** the manual version is rebuilding the week from sent mail and chats and then writing a status update. The skill wins only if it is faster than that and right enough that nobody double-checks it. The bar is a two-minute read, ready to paste upward.

**Job statement:** Given the person's request and their own read access, produce a two-minute recap page of their own past week, with linked evidence, fixed-rule project status, the week ahead and a copyable Progress / Plans / Problems version, for an AHEAD employee, without acting, inventing anything, or counting anything as done without a link.

**Classification:** a chat skill. The same folder installs as a Claude skill and as a Glean Skill. It is not a Glean Agent and has no schedule or trigger.

## 2. Trigger and non-trigger conditions

Both surfaces route on `name` and `description` only, so every trigger and every boundary lives in the description.

### Triggers

Any request that mentions the week (my week, this week, last week, the past week, weekly) together with any word for a look back: recap, overview, summary, review, rundown, roundup, wrap-up, highlights, report or status update, or any other word with the same meaning. The owner set this rule on 2026-09-28. For example: "give me an overview of my week", "weekly summary", "wrap up my week", "week in review", "recap my week", "how did my week go", "what did I get done this week", "what slipped and what's on deck", "write my Progress / Plans / Problems", or "use ahead-weekly-recap for this week". Glean also offers the slash command `/ahead-weekly-recap`.

### Does not trigger when

- today, since yesterday, or catching up after time off ("what needs me today?", "catch me up, I was out Thursday and Friday"), which belongs to ahead-daily-digest;
- one specific meeting ("prep me for my 1:1 with Meredith"), which belongs to ahead-meeting-prep-and-notes;
- a whole team's week;
- a performance review or self-assessment;
- a calendar lookup with no word for a recap in it ("what's on my calendar next week?");
- a request to act, such as sending the update, including one made after a recap (Section 4).

### Boundaries

- "What came out of my meetings this week?" is the recap, because it covers the week, not one meeting.
- A longer window ("the last two weeks") is still the recap. A request tied to a performance review is not.
- Catching up after time off goes to the daily digest even when the week is mentioned ("I was out this week, what needs me?"), because the digest is built for what needs the person now.
- "Overview of next week" mentions the week and an overview word, so it runs the recap, whose On deck part covers the week ahead.

## 3. Inputs

| Input | Format | Required? | Provenance | Sensitivity | Missing-input behavior |
|---|---|---:|---|---|---|
| The request | Chat text | Yes | The person | Internal | Not applicable |
| Window | Words in the request | No | The person | Internal | Default: the 7 days ending today, including today. "My week", "this week" or no window means the default; "last week" means the previous Monday to Sunday. The dates are always stated |
| Mail | Mail the person sent and received | Expected | The person's own access | Internal, may include client matters | Named as not read; built from the rest |
| Calendar | The window and the 7 days after today | Expected | Same | Internal | A notice under the header; On deck says the calendar could not be read; never shown as a light or free week |
| Chats and channels | Channels and group chats; direct messages where the person has them | Expected; direct messages optional | Same | Internal, may be private | Named as not read or not checked |
| Documents | Items the person created, edited, shared or commented on, including meeting notes and transcripts | Expected | Same | Internal, may include client matters | Named as not read |
| Other work systems | Trackers, CRM, service desk | Optional | Same | Varies | Used only when readable; otherwise named as not checked |
| Identity and time zone | The person's own scheduled items | Yes | The surface | Internal | Central Time (America/Chicago) unless the person's own meetings show another zone; never a separate lookup. The page says which, and anyone can switch it |

On Glean, sources come through Glean's own connectors. On Claude, they come only through the Glean connector, AHEAD's approved route. The skill sees only what the person can already see. Saved memory and earlier chats can suggest a project name, never an item or evidence. Earlier digests, recaps, briefs and AI summaries, including this skill's own pages, are never a source; every run is built fresh from the original mail, calendar entries, chats and documents, and cites them.

## 4. Outputs

### Delivery

The recap comes in two places that match, built from the same lists so they show the same items, statuses and counts. The owner chose this on 2026-09-28 so a person can read it either way, in place of the kit's rule of a two or three sentence reply.

1. **Tables in the chat reply:** the recap itself, with nothing before it, ending with the upward version in a plain text code block and the Checked line.
2. **A page** from `assets/recap-template.html`, beside the chat: a Claude artifact, or a Glean interactive page. Only the four placeholders are replaced. If a page isn't possible, a document with the same parts in the same order. If neither works, the chat tables stand alone.

A form the person names (a page, a document or chat) is given alone.

The only thing the skill creates is the recap itself. Nothing is sent, posted, shared or saved beyond it.

### The page, top to bottom

1. **Header:** "Weekly recap for [name]", the headline, the dates with the number of days covered, the time zone with a switch (ET, CT, MT, PT, UTC, and the viewer's own zone when it isn't one of those) when anything has a time, and how many projects are on track, need attention or are blocked.
2. **Notice**, only when mail or the calendar could not be read.
3. **Projects:** a card per project, up to 6, then Other, each with its status, a reason line naming the item behind it, and counts of Done, Possibly done and Still open items.
4. **Done:** each item with its evidence as links.
5. **Possibly done:** each item with what is missing.
6. **Still open:** each item with whom it is with and its due date, or that it slipped.
7. **On deck:** the 7 days after today, grouped by date, then the folded line.
8. **Progress / Plans / Problems**, with a Copy button.
9. **Checked line.**

### Data the page takes

`name`, `today`, `week {start, end}`, `timeZone`, `zoneKnown`, `headline`, optional `notice`, optional `calendarRead`, `projects [{id, name}]`, `done [{project, text, evidence [{label, url}]}]`, `possibly [{project, text, missing}]`, `open [{project, text, with, due, blocked}]`, `ahead [{date, start, end, text, project}]`, with `start` and `end` in UTC for meetings, optional `aheadMore`, `ppp {progress, plans, problems}` and `checked`. Any time inside text is written as `[[t:ISO]]` so it follows the switch. The template's opening comment is the full reference.

### What the page works out itself

- every count, including the header's status counts and each card's counts;
- meeting times, and the date each meeting falls on, in whichever zone the viewer picks;
- each project's status and reason, from the status rules below;
- whether an open item slipped, from its stated due date and `today`;
- how many days the recap covers, so a window that isn't 7 days shows;
- the Progress / Plans / Problems text, in its fixed shape;
- a Done item without an `https://` link, which it shows under Possibly done as having no linked evidence.

### Status rules

Every project gets one status from these rules and nothing else, with a reason line naming the item behind it.

- **Blocked:** a source says the work is blocked, or something the person is waiting on from someone else is past its due date.
- **Needs attention:** something with the person is past its due date, or an item is only possibly done.
- **On track:** neither.

The meanings follow the familiar green, yellow and red status definitions, but the trigger for each color is a fact in the lists, so a color is never a judgment call. Yellow and red are functional colors outside the AHEAD palette, which has none; green is AHEAD Green.

### Content rules

- **What counts as done:** something read during this run, that can be linked, showing the work happened (a sent message or file that delivers it, a shared or final document, someone confirming it, a recorded decision the person made or drove, a closed tracker item, or a record that a meeting the person ran took place). Never on its own: viewing something, a calendar entry, a draft edit, a mention, a stated plan, or memory.
- **Currency:** Still open lists only items that had activity in the window or fall due in the next 7 days.
- **Still-open check:** before an item is listed as with the person, its thread is looked at once. Done moves to Done; handled by someone else or withdrawn is dropped.
- **Promises and asks:** what the person sent is read as well as what they received. A promise they made or an ask meant for them, especially one with a date, stays under Still open until something shows it done, and it slipped once the date has passed.
- **Possibly-done check:** before an item is listed as possibly done, it is checked once for a sign it was sent or shared, such as a message it was attached to or a copy in a shared chat or folder. With one, it is done.
- **One entry per piece of work,** with its best evidence, even when it shows up in several places.
- **On deck:** every meeting with other attendees in the next 7 days that is not routine, plus deadlines and items falling due, up to 8, in date order. Routine recurring meetings are folded into one line that names each with its day. Nothing is dropped silently.
- **Whose work:** only the person's own. An ask counts only when it was meant for them. Asked about someone else's week, the skill says the recap covers only the person's own and offers that.
- **Numbers:** only when a source states them, or as counts of the recap's own items.
- **Voice:** facts, not verdicts. No praise words such as strong, great, productive, solid or busy. No commands, apologies, padding or narration. Nothing before the recap. No names of the skill, a workflow, a tool or a retrieval method anywhere the person sees.
- **Length:** about 10 Done, 5 Possibly done and 8 Still open items on a typical week, most significant first.

### The chat reply

The recap as tables: a header table (name, week, time zone, status counts), the Summary line with the headline, then Projects, Done, Possibly done, Still open and On deck tables, the folded line, the upward version in a plain text code block, and the Checked line. It matches the page item for item, and it never narrates or adds a summary after the tables.

### The upward version

At the end every time. Progress uses only Done items; Plans come from On deck and open items with the person; Problems come from slipped items, blockers and waits, each naming what is needed from whom, and by when when a source says so, or "None this week." One to three sentences each, no emoji, no links, work outcomes only, no private matters, never a quote from a private message. In chat, when asked again, it comes in one plain text code block.

### Failure behavior

- One source fails: named on the Checked line; the recap is built from the rest. One attempt per source.
- Calendar fails: a notice under the header, and On deck says the calendar could not be read.
- Nothing can be read: two sentences saying so, no page or tables, and an offer to lay the recap out from notes the person pastes.
- A quiet week: reported as quiet, with each empty part saying so.
- A page isn't possible: a document beside the chat tables; if neither a page nor a document works, the chat tables alone.
- Asked to act after the recap: a new request the surface handles normally, with its own confirmations. The skill does not refuse it, hold the conversation, or answer with another recap.

## 5. Non-goals and out-of-scope handling

This capability does not send, post, reply, schedule, accept, edit, move, share, delete or save anything beyond the recap itself; run as an agent, on a schedule or from a trigger; recap a whole team's week, compare people or judge performance; write performance reviews, daily digests or meeting prep; or count anything as done without a link. Out-of-scope requests get the surface's normal answer, or the neighbor skill when installed.

## 6. Behavior and platform design

- **Capability type:** one folder for both surfaces. The same `SKILL.md` runs on both.
- **Claude adapter:** installed as a custom skill. The page is an HTML artifact beside the chat. Data comes only through the Glean connector. Claude may hand the whole request to Glean's assistant through the connector, which reports no skills available, so a handed-off answer is Glean's plain assistant, not this skill; the log records it.
- **Glean adapter:** uploaded as a personal Skill. The page is an interactive page, which Glean shows in a sandboxed frame; the document fallback is a Glean document. Glean routes most reliably in thinking mode. Glean may carry usage-based pricing for interactive pages.
- **Instructions:** loose. `SKILL.md` names no tool, product or connector, on purpose, although Glean's own authoring guide suggests naming tools; AHEAD's testing showed strict tool names confused the assistant.
- **Page design:** the shared AHEAD page design (the daily digest's v0.2.0 page): the same CSS variables, the 69 degree header gradient, Poppins in three weights, a JSON data island, text-only rendering, links only when they start with `https://`, no network calls, and one breakpoint at 640px. The font slots are plain text islands that the page turns into fonts only when filled, so an unfilled slot falls back to a system font without a console error. The time zone switch is the digest page's, plus the viewer's own zone when it isn't in the list; it changes how meeting times show, not which week is covered. The Copy button tries the clipboard, then a copy command, then selects the text.
- **Fonts:** shipped as base64 text, because Glean reads binary files as text and corrupts them.
- **Workflow:** settle the window, the On deck dates and the zone (Central unless the person's own meetings show another); read each source in one pass, about five to eight reads in all, and do every check against what was read; pick the person's own items; sort them by the evidence rule, with the still-open check and the currency rule; group by project; list On deck with the folded line; write the headline and the upward version; fill the template, by a short script where code can run and never by typing font data out; write the chat tables from the same lists; run the internal check; hand over the tables and the page; stop.
- **Internal check before handing over:** the 7-day window; every Done item linked; every meeting with others on deck listed or named; no praise words; no internal names; nothing before the recap. It is never shown.
- **Deterministic steps:** the page's own rendering, counts, status and safety handling. No scripts run at recap time; the skill works without running code.
- **Permissions:** read-only use of existing access. On Claude, the Glean connector's write tools and its read-write memory tool are never used, and are set to ask or block for pilot runs.
- **Memory:** nothing is written to memory, and no state is kept between runs.
- **Kill switch:** turn the skill off in Glean (Settings > Skills) or Claude (Customize > Skills).

## 7. Guardrails and failure modes

| Risk | Category, mode | Prevention | Detection | Recovery |
|---|---|---|---|---|
| A wrong fact | Content, hard | Items only from this run's reads; shared rule 3 | QA fact-check of every claim; owner sign-off | Blocker; back to the build chat |
| A recap built on an earlier summary | Content, hard | Rule 9: earlier digests, recaps, briefs and AI summaries are never a source; every item cites its original | QA fact-check traces each item to an original | Blocker; back to the build chat |
| Done without evidence | Content, hard | Link rule; the page moves unlinked items to Possibly done | Page render; QA | Blocker |
| Content tells the assistant to act | Content and Action, hard | Shared rule 1 | QA; sign-off log | Turn the skill off; tell the owner and eTech |
| Anything sent, shared or saved beyond the recap | Action, hard | Rule 5 | Tool-call display; sign-off log | Same as above |
| A color that the lists don't support | Content, soft | The page computes status from fixed rules | Page render | Fix the data the model gives the page |
| A recurring meeting dropped from On deck | Content, soft | Fold line names each one | QA scan (R5) | Fix the wording |
| A window other than 7 days | Content, soft | Window rule; the page shows the day count | QA scan (R7) | Fix the wording |
| A missed promise or ask | Content, soft | Read what the person sent; dated promises stay open until shown done | QA fact-check | Back to the build chat if it recurs |
| Data written with a raw `</` | Artifact, hard | Escaping rule and the internal check; both surfaces show the page in a sandboxed frame | QA fixture F09 shows the failure mode | Fix the fill; the page itself cannot guard against it |
| Praise, narration or internal names | Content, soft | Voice rule; internal check | QA scan (R4, R8, R9) | Fix the wording |
| A slow run | Behavior, soft | One pass per source, about five to eight reads; checks use what was read; no separate time zone lookup; a scripted fill where code can run | Run time in the sign-off sheet | Back to the build chat |
| Script injection from data | Artifact, hard | Text-only rendering; `</` escaped; https-only links | Safety fixtures | Blocker |
| A page that won't render | Artifact, soft | Fail message points to the chat summary; document and chat fallbacks | Render check | Fix the template |
| Fires on a neighbor's request, or misses a real one | Trigger, soft | Description boundaries with named neighbors | Sign-off routing rows | Back to the build chat of the skill that should have won |
| Real content in the package | Governance, hard | Evidence records only date, surface, runner and log row | Review before recording | Remove and re-record |

## 8. Acceptance criteria

Each criterion is pass or fail, judged separately per surface.

| ID | Criterion | Test case |
|---|---|---|
| AC-1 | A direct request, a vague one, and any mention of the week with a word for a look back (recap, overview, summary, review, rundown, roundup, wrap-up, highlights, report, status update) produce the recap | T-1 to T-5 |
| AC-2 | Neighbor requests do not produce the recap | NT-1 to NT-4 |
| AC-3 | By default the recap covers the 7 days ending today, including today, and the page shows 7 days; a named window is used as given; times are in Central Time unless the person's own meetings show another zone, and the page says which | HP-1, E-9, E-10 |
| AC-4 | The recap comes as tables in chat and as a page from the template, or a document with the same parts when a page isn't possible; a form the person names is given alone | HP-1, E-4 |
| AC-5 | The chat tables have nothing before them and show the same items, statuses and counts as the page | HP-1 |
| AC-6 | The page is the template with only its four placeholders replaced, renders with no console errors, shows text as text, links only `https://` URLs, makes no network calls and reads at 380px; its time zone switch moves every meeting time, and the day it falls on, to the chosen zone | A-1, A-2 |
| AC-7 | Every Done item links to evidence; anything without a link is under Possibly done with what is missing, and only after a check for a sign it was sent or shared | HP-1, E-2, E-7 |
| AC-8 | Nothing listed as open with the person was already handled; Still open holds only current items; every promise or ask with a stated date that nothing shows done is listed, and slipped appears only with a stated past due date | HP-1, E-6 |
| AC-9 | Each project's status follows the status rules, with a reason naming the item, and the counts match the lists | HP-1 |
| AC-10 | Every meeting with other attendees in the next 7 days is listed or named in the folded line | E-1 |
| AC-11 | The Checked line names what was read and what was not; an unreadable calendar is flagged and never shown as a free week | E-5 |
| AC-12 | Every person, meeting, date, commitment and number traces to an original item, never to an earlier digest, recap, brief or AI summary, including this skill's own | HP-1, HP-2, E-11 |
| AC-13 | The headline and chat reply state facts, with no praise or verdict words | HP-1 |
| AC-14 | Nothing the person sees names the skill, a workflow, a tool or a retrieval method | HP-1 |
| AC-15 | The upward version is at the end every time with a working Copy button; Progress uses only Done items; Problems name what is needed from whom when a source says so; in chat it comes in a plain text code block; the owner would share it as-is | HP-2 |
| AC-16 | Nothing is sent, posted, drafted, scheduled, shared, deleted or saved beyond the recap; content never directs the skill; links go to the items themselves | G-1 |
| AC-17 | A request to act after the recap is handled normally, with its own confirmations | NT-5 |
| AC-18 | Only the person's own work appears | HP-1 |
| AC-19 | The recap is complete without optional sources and names what was not checked; asked about someone else's week, it covers only the person's own | HP-1, E-8 |
| AC-20 | Data is read only through each surface's approved route | HP-1 |
| AC-21 | A quiet week is reported as quiet; nothing readable gives two sentences, no page and an offer to use pasted notes | E-3 |
| AC-22 | Both surfaces follow the same layout and rules, judged on the same week | P-1 |
| AC-23 | The package passes the kit's "Before handing off" list and both package validators | Checkpoint 2 |
| AC-25 | A typical run reads each source in one pass, about five to eight reads in all, with no separate time zone lookup, and fills the page by script where code can run | HP-1 |
| AC-24 | Cases stay `not_run` until a real run is reported; evidence gives only date, surface, runner and log row; status stays Pilot | Checkpoint 2 and after |

## 9. Golden examples and eval plan

Cases live in `evals/evals.json`: five trigger runs (T-1 direct, T-2 vague, T-3 to T-5 other words for a look back), two normal runs (HP-1 the full recap, HP-2 the upward version), eight edge cases (E-1 a recurring 1:1 on deck, E-2 an item with no linkable evidence, E-3 a quiet week, E-4 chat only, E-5 an unreadable source or calendar, E-6 a dated promise in something the person sent, E-7 a file shared only in a chat, E-8 someone else's week, E-9 no zone found, E-10 meetings in another zone, E-11 earlier summaries of the week exist), five non-triggers (NT-1 "What needs me today?", NT-2 catching up after time off, NT-3 one meeting, NT-4 a calendar lookup, NT-5 a follow-up to act), one guardrail (G-1), two page checks per surface (A-1 the page, A-2 the time zone switch) and one parity comparison (P-1). The minimum per surface is two normal, one edge and one non-trigger. Every case is `not_run` until a real run is reported; each surface is its own track.

Testing is real use: the QA chat checks one real Claude-side sample page from the owner's week, and the owner's sign-off sheet runs the direct, vague, neighbor and routing prompts on both surfaces. The headless page checks at checkpoint 2 test the template, not a surface.

## 10. Dependencies and resources

- `assets/recap-template.html`: the page template, with its data format in the opening comment.
- `assets/poppins-latin-400-normal.woff2.b64.txt`, `assets/poppins-latin-500-normal.woff2.b64.txt`, `assets/poppins-latin-600-normal.woff2.b64.txt`: Poppins as base64 text, unchanged from the kit's design folder.
- `assets/Poppins-OFL.txt`: the font license.
- `references/ahead-shared-rules.md`: the four shared rules, v1.0, frozen.
- `references/comparison-matrix.md`: the side-by-side against the golden references, and every source.
- `references/platform-matrix.md`: how each surface meets the contract.
- `evals/evals.json`: the cases.
- `LICENSE-APACHE-2.0`: notice and license for adapted material.
- Package checks run outside the package: the builder's validator unchanged, an adjusted copy, and the kit's "Before handing off" list with the page checks. No scripts ship in the package.
- **Platform references, checked 2026-09-28:** Glean Skills user guide (routing on name and description, thinking mode, Personal outranks Shared, 100 files, 10 MB zip, 16 MB unzipped); Glean interactive artifacts (HTML pages shown in a sandboxed frame; naming the format steers the output; may carry usage-based pricing), docs.glean.com/user-guide/assistant/html-artifacts, Aug 7, 2026; Glean Canvas documents; the Agent Skills specification (description up to 1,024 characters); the Claude Help Center, which still gives a 200-character description limit (Section 12).

## 11. Release and governance

- **Versioning:** semantic versioning. 0.3.0 changes the delivery and the rules, so it is a minor version.
- **Sensitivity:** Internal. The package holds no data. A recap page shows the person their own content, which may include client matters, and is never shared by the skill.
- **Reviews:** the QA chat, then the owner's sign-off sheet on both surfaces. Rollout beyond the owner is Grace Gallagher's decision; org-wide publication also goes through the AHEAD eTech review. A passing validator is not approval.
- **License and notice:** `LICENSE-APACHE-2.0` names the three adapted Apache-2.0 files, cites knowledge-work-plugins at `da38ec1` (byte-identical to the earlier `1c7187c4` copies), and carries the standard license text with nothing after it. Ideas taken from stakeholder-update, the Glean agent-plugins references (MIT), the skill-creator guidance and the morning example skill are recorded in the comparison matrix; no text was copied from them. Poppins ships with its OFL license.
- **Rollback:** re-upload the previous zip under the same name. After publication on Glean, remove the Personal copy, since it outranks a Shared copy with the same name.

## 12. Open items

Still open:

- [NEEDS PLATFORM VERIFICATION: page on each surface] Whether each surface shows the filled template as a page, with the fonts and the Copy button working, and whether Glean keeps the template rather than writing its own page. The QA chat and the owner's sign-off runs settle it.
- [NEEDS PLATFORM VERIFICATION: Claude description length] The Agent Skills limit is 1,024 characters and the description is 948, but the Claude Help Center still gives 200. If Claude rejects the upload, use this 195-character fallback: "Recaps an AHEAD employee's own week by project, with a Progress / Plans / Problems update. Use for any mention of the week with a recap, overview, summary or review. Not for today or one meeting."
- The surface runs in the owner's sign-off sheet. The owner signed off on 2026-09-28 before running them.
- Further approvals in the README's Approvals table.
- More real use after the pilot runs.

Decided by the owner (2026-09-28, 0.5.1):

- Earlier digests, recaps, briefs and AI summaries, including this skill's own, are never a source. Every run is built fresh from the person's mail, calendar, chats and documents, and cites the original item. The rule is in this skill only; the frozen shared rules are unchanged.

Decided by the owner for speed (2026-09-28):

- Central Time (America/Chicago) is the default. The zone the person's own scheduled items show wins when there is one, and the time zone is never looked up separately. The page has a time zone switch like the daily digest's, so anyone elsewhere can change the view.
- Each source is read in one pass, about five to eight reads for a typical week, and every check works from what was read. Looking something up again is only for an answer that would move an item or change a color, once per item.
- Where code can run, the page is filled by a short script, so the model writes only the data and never types font data out.

Decided by the owner after the QA pass (2026-09-28):

- The chat reply is the recap as tables again, beside the page, so a person can read it either way. This replaces the kit's rule of a two or three sentence reply for this skill; the other two skills still follow it.
- Any mention of the week with a word for a look back triggers the recap. The description is now 948 characters, above the kit's 600 to 800 aim, to carry the list of words.

Decided at checkpoint 1 (approved by the owner, 2026-09-28):

- The description drops the R1 draft's "as a structured page", since the kit's pattern keeps delivery details out of the description. The colon after "past week" became ", covering" so the description stays a plain YAML line.
- Still open lists only items that moved this week or fall due in the next 7 days.
- The page works out every count, each status and reason, slipped items and the day span, so the data carries no typed counts.
- Page checks run outside the zip, next to the package validator, because a chat skill can't depend on scripts.

Settled:

- Glean skill availability (0.1.1) and Glean rendering of the chat tables (0.2.0), both shown in the owner's own Glean runs.

Kept as noted:

- The status labels stay On track, Needs attention and Blocked.
- The internal-comms example skill on Claude also writes 3P updates and may answer a request for the upward version.
- Overlaps for Grace: the "[Productivity] Weekly Action Tracker" agent and its copies, Glean's built-in memory skill with its weekly-summary workflow, Glean's Weekly work report template, and the planned Action Capture & Follow-Up skill.
- Interactive pages on Glean may carry usage-based pricing, so a weekly page per person has a cost the chat version didn't.

QA pass (2026-09-28), run in the build chat at the owner's request, so not independent; the report is `ahead-weekly-recap-v0.3.1-qa-report.md`, outside the package. On the 0.3.0 sample it found one wrong fact (a deck marked as never shared that sat in a shared chat) and two missed items (a dated promise that slipped, and an ask from a colleague). On the template it found six edge cases that did not resolve cleanly: an item with the person's own name in `with` read as a wait on someone else, a partly pasted font logged warnings, items with no text drew blank rows, a missing date left a dangling "to", duplicate project ids drew two cards, and a missing time zone gave no note. All are fixed in 0.3.1 and re-tested with 24 fixtures at two widths, and the sample was rebuilt.

Package checks at checkpoint 2 (2026-09-28):

- The builder's validator, run unchanged against a copy of the package with the validator placed inside it: FAIL with 8 errors, all from checks hardwired to the builder's own package (two builder-only files, the builder's own name, and five of its own case types). Expected.
- The adjusted copy (`validate_weekly_recap.py`, outside the zip): PASS in structural mode with the zip. Its file list now includes the five files in `assets/`.
- The adjusted copy at the install gate, per surface: blocked by exactly three items, owner sign-off and the two platform checks above.
- The kit's "Before handing off" list: every item passes. Flat frontmatter; `name` matches the folder; an 808-character description with "Use when" and "Do not use"; no tool, product or connector names outside the `ahead-platform` field; shared rules md5 `328314a998bc`; no binary files; each font decodes to the SHA-256 in the QA brief; the zip is under 10 MB and 100 files with the folder at its root; no em dashes; `evals/evals.json` parses and has the direct, vague and neighbor cases; the version is 0.3.0 with a dated README change note.
- The template, with the QA fixtures (a full week of 6 projects plus Other and 10 items on deck, a quiet week, an unreadable calendar with a notice, done items with empty, `javascript:` and `http://` evidence, every status color, a broken data island), rendered at 1100px and 380px: no console errors or warnings, no page overflow, only `https://` links, a `<script>` title shown as text, `</script>` in the data shown as text, the Copy button copying the exact text, and the failure message for broken data. An unfilled font slot falls back to a system font with no error.
- One real Claude-side sample page from the owner's week, made in this build chat by following `SKILL.md` and read through the Glean connector only: rendered with no console errors at both widths, and every item traced to its source (the handoff note lists them).

Re-run on 0.5.0 (2026-09-28): every package check passes again; the 24 QA fixtures render clean at both widths; six time zone fixtures (Central known, no zone, an invalid zone, Tokyo, no times, and a viewer in India) show the right label, move every meeting time and its day when switched, and add the viewer's own zone; and the sample's chat tables still match its page, now including on-deck times.

Re-run on 0.4.0 (2026-09-28): the kit's list, the adjusted validator, the fail-closed tests and the independent QA checks pass again; the 24 fixtures still render clean at both widths; and an alignment check comparing the sample's chat tables with its page matches every project, status, item and count, and catches a changed status, a dropped item and wrong header counts.

Re-run on 0.3.1 (2026-09-28): the kit's list passes; the adjusted validator passes and the builder's unchanged validator fails only on its 8 hardwired checks; 9 of 9 fail-closed tests fail as they should; an independent QA check script passes 23 of 23; the QA's 24 fixtures render at 1100px and 380px with no console errors, no layout problems, only `https://` links and a working Copy button, including when the clipboard is blocked; and the rebuilt sample traces item by item to its sources.

## 13. Quality Checklist

| Check | Status |
|---|---|
| One job statement and a platform classification | Done (Section 1) |
| Spec before implementation | Done: checkpoint 1 approved, then this spec, then the rest |
| Concrete triggers and non-triggers | Done (Section 2), with named neighbors |
| Inputs and outputs fully specified | Done (Sections 3 and 4) |
| Non-goals | Done (Section 5) |
| One contract for both surfaces | Done (Section 6 and the platform matrix) |
| No untested track claimed | Both tracks `not_run` |
| Scenario testing offered | Yes: the QA chat and the owner's sign-off sheet |
| Approved language from versioned resources | The shared rules file and the page template |
| Deterministic builders and validators | The page does its own counting and safety; package checks run outside the zip |
| Minimum cases | Done in `evals/evals.json` |
| Generated artifact validated | The template rendered with the QA fixtures at 1100px and 380px, and the sample page checked |
| Integrity, security, privacy and versioning | Checked (Section 12) |

## 14. Change Log

- **0.5.2 (2026-09-28):** Owner sign-off recorded in `approved-by` and `approved-date`, with a `further-approvals` field pointing to a new Approvals table in the README. No change to what the skill does.
- **0.5.1 (2026-09-28):** New rule 9: earlier digests, recaps, briefs and AI summaries, including this skill's own, are never a source; every run is built fresh and cites the original item. A matching line in the internal check, criterion AC-12, a guardrail row and case E-11.
- **0.5.0 (2026-09-28):** Faster runs: one pass per source with a budget of about five to eight reads, checks against what was read, and a scripted fill where code can run. Central Time by default, or the zone the person's own meetings show, with a time zone switch on the page. On deck meetings carry start times, and the chat's On deck table gains a Time column.
- **0.4.0 (2026-09-28):** The recap comes as tables in chat and as the page, built from the same lists. The description triggers on any mention of the week with a word for a look back. The page's failure message points to the chat tables.
- **0.3.1 (2026-09-28):** QA fixes. The skill reads what the person sent for promises and asks, checks once for a share before calling anything possibly done, lists each piece of work once, uses a form the person names, and covers only the person's own week when asked about someone else's. The page treats the person's own name or "me" as their own item, uses a font only when the pasted data is a complete file, skips items with no text, handles missing dates and duplicate project ids, and meets text contrast on the card counts.
- **0.3.0 (2026-09-28):** The recap is a page from a new template, then a document, then chat; the description is rewritten with named neighbors; nothing comes before the recap; On deck names every folded meeting; Done items need a link; the window is exactly 7 days; facts, not verdicts; no internal names; each project's status is worked out by the page with a reason; viewing is not evidence; stale items drop out; the upward version is on the page every time with Copy.
- **0.2.0 (2026-09-24):** Chat recap as markdown tables with fixed status colors.
- **0.1.1 (2026-09-24):** Flat frontmatter so Glean would load the skill.
- **0.1.0 (2026-09-24):** First chat recap.
