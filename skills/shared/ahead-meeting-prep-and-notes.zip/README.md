# AHEAD Meeting Prep and Notes

- **Version:** 0.8.0
- **Status:** Approved for the skills launch. Owner sign-off: Akbar Aman, owner, Enterprise AI, 2026-09-28. Second approval: Grace Gallagher, Forward Deployed Engineer, Solutions Engineering, 2026-09-28.
- **Owner:** Akbar Aman, akbar.aman@ahead.com, Enterprise AI
- **Platforms:** Claude and Glean, from this one folder
- **Sensitivity:** Internal

This README carries the package through its skills-launch approval. The sections on what was validated, what wasn't, and known limitations still reflect the pilot's real-use runs; they are refreshed as more launch-day use comes in.

## What it does

Ask Glean Assistant or Claude chat about any one meeting, before or after it, and this skill is meant to be the one that answers: prep, an agenda, getting aligned, what to raise, a debrief, notes or action items. You get one of two things back, depending on timing.

Before the meeting, a short brief: who's attending and why they matter, why the meeting exists, relevant recent emails, chats and documents, anything left open from last time, and a few suggested points or questions. It takes about two minutes to read. Ask for an agenda instead and you get one you can share: a one-line goal and timed items that fit the meeting, with private prep left out.

After the meeting, notes from a transcript or your own notes: the decisions made, action items with the owner and date only where they were stated, open questions, and, if you ask, a follow-up message as text you can copy.

The brief or notes open as a document beside the chat, titled "Prep:" or "Notes:" with the meeting and date, and the chat gets two or three sentences that end by offering a web page instead. If you name a format up front, such as "as a web page", you get that. Ask for another format afterward and it redoes the same content. The only question it ever asks is one it can't work out for itself, such as which of two meetings you mean. In Glean the artifact is saved to your Library where you can find it later. If you run the skill inside a shared Glean Project, project members can see it too, so use a normal chat for anything sensitive.

If it isn't clear which meeting you mean, or whether you want prep or notes, it asks you once. It says plainly what it couldn't check, and it never fills a gap with a guess. Where an owner wasn't stated, you'll see "owner unclear".

Every run starts fresh from your mail, calendar, chats and documents, and cites the original item. Earlier digests, recaps, briefs and AI summaries, including ones this skill made, are never used as sources.

The skill is read-only. It never sends, schedules, accepts or edits anything, and the follow-up is text at the end of the notes, not a draft or a sent message. The one thing it creates is the artifact holding the brief or notes, and it never shares it. If you then ask for something in the same chat, such as sending that follow-up, that's a normal request, and the assistant handles it with its usual confirmations.

## What it's not for

Scheduling or rescheduling meetings, daily digests (use ahead-daily-digest), weekly recaps, summarizing an email thread, simple calendar lookups, or requests to act. Those get a normal answer, or the matching skill where one is installed.

## Install on Glean

1. In Glean, go to Settings > Skills, click Add, choose Upload a Skill, and select `ahead-meeting-prep-and-notes.zip`.
2. The skill appears under the Personal tab. Make sure it is turned on.
3. Use thinking mode when you ask, since Glean's skill routing works best there. If Glean answers without the skill, and its answer ends by offering to save the approach as a new skill, type /ahead-meeting-prep-and-notes before your request.

Uploading a zip with the same skill name later offers to replace the existing skill.

## Install on Claude

Claude needs three things first:

- Your organization must have Skills and code execution turned on. Organization owners do this in Organization settings > Plugins & skills.
- The Glean connector must be connected. It is AHEAD's approved route to your mail, calendar, chats and documents on Claude, so don't use a Microsoft 365 connector with this skill.
- In the Glean connector's settings, set its write tools to ask or block. The skill's read-only promise is an instruction, and this setting backs it up.

Then:

1. Go to Customize > Skills, click +, then Create skill, and upload `ahead-meeting-prep-and-notes.zip`.
2. Make sure the skill is toggled on.

Install steps checked against the Claude Help Center article "Use skills in Claude" on 2026-09-24.

## Transcripts

At AHEAD, meeting transcripts are often not available to search, so for notes you'll usually paste the transcript or your own notes. If none is found, the skill says so and asks you to paste one. It never writes notes from a meeting title or invite alone.

## Recording and transcription policy

AHEAD's "Updates to Recording and Transcription Policies" (July 9, 2026) says to tell participants before recording, to say clearly if AI will transcribe or summarize, and that if anyone objects, you must not record or use the AI tool for that session. It treats transcripts as confidential business records and allows only AHEAD-approved AI tools.

In line with that, if you or the transcript say someone objected to recording or AI use, the skill won't write notes from it and will say why. It doesn't add a reminder to every answer. The policy doesn't cover pasting a transcript into an AI assistant after the meeting, and that question is open with Grace.

## What has been checked so far

Only structural checks, on 2026-09-24, plus three build-chat samples on 2026-09-28 (a real prep, notes from a real Teams transcript, and a constructed transcript with an objection) left for the kit's QA chat to grade. A build-chat self-QA on 2026-09-28 found no wrong facts and no guardrail breaks; its four gap findings are fixed in 0.4.1. The kit's independent QA still applies. The builder's validator, run unchanged, fails on checks hardwired to the builder's own package (its name, its bundled references and its own test types) and passes everything specific to this package. A copy adjusted for this package, which adds Glean's upload limits, passes. Separate build checks on the name, description, shared rules and license pass 14 of 14. No real runs yet, so both the Claude and Glean evaluation tracks are not_run. This section is completed after real use.

## Where it came from

The skill adapts, with changes, parts of three Apache-2.0 files from anthropics/knowledge-work-plugins, cited at commit da38ec1 (first read at 1c7187c4; the files are byte-identical at both): legal/skills/meeting-briefing, sales/skills/call-prep, and sales/skills/call-summary. Version 0.4.0 also adapts ideas, not text, from gleanwork/agent-plugins (meeting-prep and skill-creation-guide, commit 93bf39d), MIT License, Copyright (c) 2025 Glean, and from Anthropic's skill-creator (Apache-2.0) and AHEAD's glean-transcript-skill. It also borrows the output shape of Glean's public Meeting recap agent page, and ideas from two AHEAD references: the meeting-notes-writer submission (Skills-Marketplace PR #74) and the "Meeting Summary and Action Items/Opps" agent. `references/comparison-matrix.md` records what was taken from each and what was changed. `LICENSE-APACHE-2.0` is the standard Apache-2.0 text.

## Change notes

- **0.8.0, 2026-09-28.** Second approval above the owner recorded (Grace Gallagher, Forward Deployed Engineer, Solutions Engineering), clearing this package for the AHEAD skills launch. Publication status moves from Pilot to Approved. No behavior change.
- **0.7.0, 2026-09-28.** New rule: earlier digests, recaps, briefs and AI summaries, including ones this skill made, are never a source. Every run is built fresh from your mail, calendar, chats and documents, citing the original item, and automatic AI recaps no longer count as meeting notes. Owner sign-off recorded (Akbar Aman), with a slot for one more approval above the owner.
- **0.6.1, 2026-09-28.** The description is rewritten trigger-first, with ten real phrasings such as "prepare for my next meeting" and "get ready for my upcoming meeting with [name]". Natural requests like these had missed on Glean that morning, while the slash command worked. No change to what the skill does.
- **0.6.0, 2026-09-28.** Agendas move in: ask for an agenda for one meeting and you get a shareable one, with a one-line goal and three to six timed items that fit the meeting's length. Owners appear only where the sources name one, and private prep is left out. The description now lists agendas. The two evaluation cases that used an agenda as a neighbor now use scheduling and rescheduling, and two agenda cases were added. An updated sign-off sheet ships outside the zip.
- **0.5.0, 2026-09-28.** The go-to for anything about one meeting, before or after: the description now catches alignment, points to raise, debriefs and action items, even without the words prep or notes. Cleaner artifacts: one link per item, at its end, as a short label, never mid-sentence or side by side, and copied exactly so every link opens. Each point is said once. Earlier briefs and AI summaries, including this skill's own, are never cited as sources. Recent items leave out broad background and the invite itself. Six evaluation cases added. Writing agendas stays out, pending the owner's confirmation.
- **0.4.1, 2026-09-28.** QA fixes before sign-off. If your time zone isn't known, times show in the invite's zone with that zone named, never a guessed conversion. "My next meeting" skips blocks with no one else on them and says which. A meeting you declined, only follow, or that was cancelled says so first. A large group meeting isn't assumed when you ask about one person. A brief now aims for about two minutes, with "why it matters" in a few words. Four evaluation cases added. Deferred by the owner: QA findings F5 to F8 and the simplicity trims.
- **0.4.0, 2026-09-28.** Refined against the owner's kit. New description with a "Do not use" line naming ahead-daily-digest and ahead-weekly-recap (M1), with the colons that broke YAML replaced by commas and "a quick calendar lookup" kept. No format question: a document by default, with a web page offered in the chat reply (M2). Recent items vetted for relevance to this meeting, up to about four, each with why it matters (M3). No system words in output (M4, rule 12). Recurring meetings read their earlier instances, a first-meeting shape, a meeting-not-found path, and notes extracted before they are written (M5). Attendees skip the person themselves, the meeting line says whether it recurs, points are ordered by priority, your own action items come first, notes say where each item was said and give a next-meeting line when one was set, and the chat reply is two or three sentences. Ten evaluation cases added from the kit's trigger and routing prompts. Citations re-pinned to da38ec1, and MIT attribution added for Glean's ideas. The kit's platform facts are recorded in the platform matrix. Rule 12 is worded to ban describing its own workings, so a meeting about skills can still say "skills". Build-chat samples produced for QA (M6).
- **0.3.0, 2026-09-24.** A format choice asked once per run. Replaced in 0.4.0.
- **0.2.0, 2026-09-24.** Output moved from a chat answer to an artifact.
- **0.1.1, 2026-09-24.** Description shortened under the 1,000-character upload limit.
- **0.1.0, 2026-09-24.** First pilot build.

## Install and publication

Owner sign-off covers installing the skill in the owner's own workspace. The owner signed off on 2026-09-28, and the second approval above the owner was recorded the same day by Grace Gallagher, clearing this package for the AHEAD skills launch alongside ahead-daily-digest and ahead-weekly-recap. Neither a passing validator nor owner sign-off alone counts as this second approval; it is recorded separately in `approved-by` and `approved-date`. For questions about AHEAD AI tools, policies or governance, see the AHEAD AI HIVE or your eTech team contact.

## Open items

Tracked in `SPEC.md` section 11. In short: whether Claude accepts the AHEAD frontmatter keys (the Glean side is confirmed), whether Glean reads the references folder, whether Teams transcripts are indexed at AHEAD, more real use, and a few decisions and suggestions for Grace. The owner's sign-off and the second approval are both now recorded.
