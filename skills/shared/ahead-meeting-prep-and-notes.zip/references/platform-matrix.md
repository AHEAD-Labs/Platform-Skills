# Platform matrix: Claude and Glean

One folder serves both platforms. SKILL.md and SPEC.md are shared, and there are no platform-specific files. This page holds the platform detail that SKILL.md leaves out on purpose, because SKILL.md names no tool, connector, or platform.

## Mapping

| Concern | Claude | Glean |
|---|---|---|
| What it is | A custom skill uploaded as a zip, used in a normal chat | A Glean Skill uploaded as a zip, used in Glean Assistant. Not an Agent. |
| Install path | Customize > Skills, +, Create skill, upload the zip. The organization must have Skills and code execution turned on in Organization settings > Plugins & skills. (Claude Help Center, checked 2026-09-24.) | Settings > Skills, Add, Upload a Skill. The skill appears under the Personal tab. (The same path the owner used for ahead-daily-digest.) |
| Zip layout | A zip containing the skill folder, as the Claude Help Center describes | A zip with the ahead-meeting-prep-and-notes/ folder inside. Accepted for ahead-daily-digest on 2026-09-24. |
| Frontmatter | Name and description drive routing. Acceptance of the other AHEAD keys is open until the owner's Claude upload. | Name and description are required. The other AHEAD keys were accepted with ahead-daily-digest on 2026-09-24. |
| Data | The Glean connector only, AHEAD's approved route to mail, calendar, chats, and files on Claude. Microsoft 365 connected directly stays off. | Glean's own connectors: Outlook mail and calendar, Teams channels and group chats, SharePoint and OneDrive. |
| Route to the data | Claude may read through the connector itself or hand the request to Glean's assistant. SKILL.md doesn't choose; each run records which happened. Rule 9 covers answers handed back. | Glean Assistant reads directly. |
| Writes | The connector's write tools set to ask or block. This is a test condition and README advice, because read-only is an instruction, not a permission. | Glean's own action confirmations. |
| Reading references/ | Bundled files are available to the skill. | Not yet verified. SKILL.md carries every rule itself, so behavior doesn't depend on it. |
| Mode for test runs | A normal chat outside any project | Thinking mode on, since skill routing works best there |
| Transcripts | Only if Glean indexes them, which is unconfirmed at AHEAD. Otherwise the person pastes one. | The same. Glean's own transcription is off at AHEAD. |
| Format choice | No format question (decision D-7). A document by default; a format the person names is made if Claude can make it; the chat reply offers a web page. | The same. A request for slides gets the document with a one-line reason, since Glean's slide generation was found unavailable from skills. Glean's clickable clarifying questions may still carry the one ask about which meeting. |
| Time zone | The calendar through the Glean connector gives UTC, and Claude may not know the person's zone. Unless the zone is known, for example from the person's profile, the skill shows the invite's zone and names it. | Glean reads the calendar's zone. |
| Output | A document artifact, or the format the person names, with a two- or three-sentence chat reply; a chat reply only where no artifact can be made | A Canvas document, or the format the person names, with a two- or three-sentence chat reply. Saved to the person's Library and indexed for search. A web page is an interactive artifact and uses FlexCredits. Inside a Glean Project, artifacts are visible to all project members. |

## Verification items

| Item | Status | Evidence |
|---|---|---|
| Glean accepts the zip with the folder inside | Closed | ahead-daily-digest, same layout, accepted by Glean on 2026-09-24 |
| Glean accepts the AHEAD frontmatter keys | Closed | ahead-daily-digest carries the same keys; same upload, 2026-09-24 |
| Claude accepts the AHEAD frontmatter keys | Open | Closes with the owner's Claude upload of this zip |
| Glean reads files under references/ | Open | Not needed for behavior; noted for completeness |
| Teams meeting transcripts are indexed at AHEAD | Open | Notes mode works from pastes either way |
| Glean creates the artifact from the skill's instruction | Closed | The owner reported 0.2.0 artifacts working on Glean, 2026-09-24; details in the run log |
| Glean shows the format question as clickable options | Closed, not needed | Decision D-7 removed the format question |
| A Glean artifact outside a Project stays private until shared | Open | Glean's docs cover sharing and Projects, not this default in so many words |

## Platform facts from the owner's kit (2026-09-28)

- Both surfaces decide whether to use a skill from its name and description only.
- In Glean, a Personal skill outranks a Shared one with the same name, so the Personal copy is removed after org publication.
- Glean's limits are 100 files, a 10 MB zip and 16 MB uncompressed. This zip is well under all three.
- Through the Claude Glean connector, Glean's assistant reports no skills available, so Glean runs happen in Glean directly.
- The Claude Glean connector can still search mail, calendar and Teams. The build chat used it for the Claude-side samples and QA can use it to fact-check.

## Intentional differences

- P-EDGE-3, the unreadable-calendar case, is Claude-only. On Claude the data connection can be turned off for one chat; there is no practical way to make the calendar unreadable on Glean for a test.
- What happens after the answer depends on each surface's own actions and confirmations. The skill's part is the same on both: it doesn't refuse the request or hold the conversation.
- On Claude, the route to the data can change from run to run. Glean has one route.

## Parity rules

- PARITY-1 uses the same pasted transcript on both surfaces and judges each against the same reference list of decisions, owners, and open questions. Wording may differ.
- A result on one surface is never evidence for the other. An untested surface stays not_run.
- Parity is not claimed where a surface lacks something the case needs, such as the unreadable-calendar set-up on Glean.
