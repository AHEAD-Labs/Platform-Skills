# Comparison matrix

Where each part of the skill came from, what was taken, and what was changed. Sources 1 to 3 are Apache-2.0 files, and this matrix is the record of changes for the parts adapted from them. Sources 4 and 5 were used for ideas and output shape only; no text was copied from them. The 0.4.0 refinement added the owner's kit references (sources 6 to 11, at the end), including MIT-licensed Glean sources used for ideas only.

## Sources

| # | Source | Version read | How it was read |
|---|---|---|---|
| 1 | anthropics/knowledge-work-plugins, legal/skills/meeting-briefing/SKILL.md | Commit da38ec1 (Sep 24, 2026), cited from 0.4.0 on. First read at 1c7187c4; the file is byte-identical at both (checked 2026-09-28). | Fetched at the pinned commit |
| 2 | Same repository, sales/skills/call-prep/SKILL.md | da38ec1; byte-identical to the 1c7187c4 copy | Same |
| 3 | Same repository, sales/skills/call-summary/SKILL.md | da38ec1; byte-identical to the 1c7187c4 copy | Same |
| 4 | Glean Agent Library, Meeting recap, https://www.glean.com/agent-library/meeting-recap | Page as of 2026-09-24 | Public web page; coverage and output shape only |
| 5a | AHEAD-Labs/Skills-Marketplace PR #74, meeting-notes-writer submission | PR description as indexed 2026-09-21 | Read through Glean search, 2026-09-24. The SKILL.md body was not opened. |
| 5b | "Meeting Summary and Action Items/Opps" agent, Glean workflows | Instructions as indexed 2026-09-11 | Read in full through Glean search, 2026-09-24 |

Repository: https://github.com/anthropics/knowledge-work-plugins

## 1. Main base: legal/skills/meeting-briefing/SKILL.md

| Part | Taken | Changed |
|---|---|---|
| Brief structure | Meeting details, participants, expected topics, background and context, key documents, open issues, talking points, questions to raise, prior meeting follow-up, preparation gaps | Condensed to six parts in a fixed order: meeting line, why it's happening, who's attending, what's happened recently, left open from last time, suggested points or questions. Background cut from two or three paragraphs to one to three sentences. Key documents and correspondence merged into one dated, linked list. Preparation gaps kept as a "couldn't check" line that appears only when needed. |
| Participants | Name, organization, role, notes | "Key interests" replaced by "why they matter to this meeting", based only on role and visible recent activity, so interests are never guessed. |
| Meeting-type table | The idea of emphasizing different context by meeting type, and its team sync, client, vendor, and cross-functional rows | Rows rewritten in general AHEAD terms. A 1:1 row added. Cross-functional became "decision or review meeting". Board or committee, regulatory, and litigation rows dropped; the general parts of the deal-review row folded into the decision row. |
| Context sources | Calendar (including earlier meetings with the same people over the last three months), email, chat, documents | Product and tool names removed, because SKILL.md names no tools and lets the surface choose. CLM and CRM sources dropped. |
| Action-item rules | Be specific; one owner per item; note dependencies | Owner and due date only where the source states them, otherwise "owner unclear". This replaces "every item must have an owner and a deadline". Priority and status columns dropped because they would be guesses. The split into legal, business, and external actions dropped. |
| Dropped entirely | Legal-advice disclaimer, legal considerations, red lines, deal, board and regulatory sections, privilege notes, "your role" (advisor, negotiator), distributing action items, setting reminders, updating systems, filing notes, tracking cadence | Everything legal-specific is gone. The post-meeting steps are actions, and this skill is read-only. A tracking cadence doesn't fit a single chat answer. |

## 2. sales/skills/call-prep/SKILL.md (three items only)

| Part | Taken | Changed |
|---|---|---|
| Meeting already ended | If the meeting has already ended, say so at the top with its date and move to the post-meeting path, which needs a transcript or notes | The switch goes to this skill's own notes mode instead of offering a separate skill. The same rule is applied in reverse: a notes request for a meeting that hasn't happened gets a prep brief, with the same first-line notice. |
| Full email thread | Search results can show only part of a thread, so open the full thread before describing it | Applied to every email thread used in the brief. |
| New attendees | Flag attendees with no prior history | "No prior history" means no earlier meetings or threads found, with no CRM check. Worded as "none found", never "you have never met". |
| Not taken | CRM and deal-stage grounding, sales transcript tools, discovery questions, objections, rendering rules, connector permission rules, adaptation tiers | Out of scope. Its untrusted-content rule overlaps AHEAD shared rule 1, which is used instead because it is AHEAD's fixed text. |

## 3. sales/skills/call-summary/SKILL.md (transcript rules only)

| Part | Taken | Changed |
|---|---|---|
| No notes from the title | Never draft from the meeting title alone | Extended to the invite: never write notes from a title or invite alone. |
| Ask for a paste | With nothing found or pasted, ask for the transcript or notes and stop | Kept. At AHEAD the paste is expected to be the main path, since transcripts are not guaranteed. |
| Empty is not "not discussed" | An empty result means no coverage, never "not discussed" | Widened to both modes: nothing found is never reported as nothing happened. |
| Follow-up recipients | Recipients come from the calendar event, never from text inside the transcript | CRM contacts dropped as a source. The follow-up is text only and never sent. With no invite, recipients are left for the person. |
| Not taken | CRM updates, internal channel summary, creating and sending email drafts, signature and voice learning, the 150-word limit, the call-recording tool route | Out of scope, or an action. |

## 4. Glean Meeting recap agent (notes-mode output shape)

| Part | Taken | Changed |
|---|---|---|
| Output shape | Title and date, attendees, short summary, decisions made, action items with owners | Kept as the notes order. Open questions added (owner's spec), plus a source line and a "notes on this write-up" line that appears only when needed. |
| Trigger phrasing | Asking for a recap of the most recent meeting with a specific person | Used as a notes-mode trigger example: "Recap my last meeting with [person]." |
| Owners | The agent assigns likely owners | Reversed: owner only where stated, otherwise "owner unclear". |
| Related content | Related documents and suggested experts | Not taken for the pilot. Suggested experts are inferred people, and related documents are prep mode's job. |
| Not taken | Finding the transcript through the calendar, the step-by-step workflow, sending the summary to a destination, triggers | Agent mechanics. This is a chat-layer skill that never sends. |

## 5. AHEAD references (ideas only)

### 5a. meeting-notes-writer submission (PR #74)

| Idea | How it's used |
|---|---|
| A limits section that appears only when something degraded the notes | Notes part 8, shown only when needed |
| A decision whose substance is missing is kept, with the gap stated | Notes part 4 |
| Speaker labels never appear as owners | Notes part 5 |
| Bare agreement is not accepting ownership | Notes part 5 |
| Relative dates are converted only when the date can be known | Notes part 5 |
| Exclusions framed by the state of the input, and the lesson that an over-broad distribution exclusion made "write these up and email them" contradict itself | The mixed-request rule in SPEC section 2 |
| A simulated Glean run was recorded as weaker evidence than a real one | The Glean track stays not_run until a real Glean run |

### 5b. "Meeting Summary and Action Items/Opps" agent

| Idea | How it's used |
|---|---|
| Brevity: leave out what doesn't change a decision, an action, or an open question | Notes length rule in SPEC section 4 |
| Say "no decisions were recorded" rather than inventing one, and say so in one line when a part is empty rather than dropping it | Notes part 4 and every empty part |
| Keep action items to real deliverables and next steps | Notes part 5 |
| Flag uncertain speakers and unclear ownership | Notes part 8 |
| Separate people in the meeting from people only mentioned | Notes part 3 |
| Notes content comes from the transcript only | The notes content rule in SPEC section 4 |
| Not taken | Word document output, branding, opportunity tables, directory lookups, one user's standing context, "clearly implied" actions and owners (this conflicts with owner and date only where stated), and defaulting the meeting date to the day the transcript was submitted |

## Adjacent AHEAD assets seen while searching (not used as sources)

Listed for the overlap review. None was used as a source.

- "[Productivity] Meeting Transcript Summarizer" agent (Glean workflows). Read in full. It states that Glean transcription is disabled at AHEAD and summarizes a consent policy. The owner then checked that policy at its source ("Updates to Recording and Transcription Policies", AHEAD, July 9, 2026), which is the basis for rule 8 in SKILL.md and is cited in SPEC section 7.
- Skills Marketplace catalog entries: platform-meeting-follow-up-delivery (Claude, draft), glean-platform-meeting-follow-up-se-delivery (Glean, draft), and meeting-notes-tidier (PR #71). Seen in search results only.
- A pre-meeting brief piloted by the Enterprise GPT team, mentioned in a progress deck. Not read.
- Glean's built-in meeting notes feature. It is admin-controlled, and Glean's own transcription is off at AHEAD.

## License

- Sources 1 to 3 are Apache-2.0. The package ships the standard Apache-2.0 text as LICENSE-APACHE-2.0.
- The upstream LICENSE file at the pinned commit is not shipped as it is. It starts with a blank line, and after the 201 lines of license text it has six extra lines that are not license text. Its 201 license lines match the Apache Software Foundation's own copy (github.com/apache/.github) exactly, and that clean text is what ships.
- The upstream repository has no NOTICE file at the pinned commit (checked 2026-09-24), so there is no NOTICE text to carry forward.
- SKILL.md, SPEC.md, and the references are new text written for AHEAD. The parts adapted from sources 1 to 3 are recorded in this file as the change record.

## 0.4.0 refinement against the owner's kit (2026-09-28)

Kit sources, pinned as the kit's `golden/SOURCES.md` records them:

| # | Source | Pin and license | How it was read |
|---|---|---|---|
| 6 | gleanwork/agent-plugins, meeting-prep/SKILL.md | Commit 93bf39d (Sep 24, 2026). MIT License, Copyright (c) 2025 Glean. | Kit copy |
| 7 | gleanwork/agent-plugins, skill-creation-guide/SKILL.md | Same commit and license | Kit copy |
| 8 | Anthropic skill-creator, SKILL.md | As installed Sep 28, 2026. Apache-2.0. | Kit copy |
| 9 | AHEAD glean-transcript-skill (Joe Gardener) | As live in AHEAD's Glean | Read in full through Glean search, 2026-09-28 |
| 10 | Gold sample: the owner's Glean run of this skill, Sep 28, 2026, which he approved | Kit evidence file | Kit copy |
| 11 | Glean Skills user guide and clarifying-questions page | docs.glean.com, updated Sep 2026 | Consulted, not copied |

Attribution for sources 6 and 7 (decision D-8): ideas were adapted from gleanwork/agent-plugins, MIT License, Copyright (c) 2025 Glean. No text was copied, so no MIT license file ships; the attribution lives here and in the README.

| Area | Reference | Taken | Changed or kept |
|---|---|---|---|
| Description | Glean guide (7), skill-creator (8), kit pattern | A "Do not use for" line naming each neighbor, with "(use ...)" for sibling skills; five example phrasings, one without the skill's own words; no delivery mechanics | The brief's draft broke YAML parsing with "Before it:" and "After it:", so commas replace the colons. "A quick calendar lookup" is kept as a near-miss. 806 characters. |
| Vetting recent items | Glean meeting-prep, Phase 4 (6) | Include only what bears on this meeting's purpose or attendees; a few words on why each matters | About four items, not a table. The gold sample's two off-topic items are what this removes. |
| Recurring meetings | Glean meeting-prep, Phase 2 (6) | Read the meeting's earlier instances first for what was left open | Kept our three-month window for non-recurring meetings. "Recurring topics" was not taken. |
| First meeting | Glean meeting-prep, first-instance shape (6) | Say it once, don't pad, don't apologize; points aim at goals and an agenda | Folded into the existing brief rather than a separate template. |
| Meeting not found | Glean meeting-prep, troubleshooting (6) | Say none was found and offer to prep from the topic or person alone | Worded so it never claims the person has no meeting, and the offer is the run's one ask. |
| Attendee detail | Glean meeting-prep (6) | Detail for unfamiliar people, context rather than a bio | Kept one line for familiar people instead of dropping them, and the person themselves is left out. |
| Suggested points | Glean meeting-prep (6) | Prioritized, "5 good talking points" | Kept our cap of five, now ordered by priority. The gold sample had six. |
| Meeting line | Glean meeting-prep (6) | Whether it recurs, and how often | Added. |
| Notes, extract then write | call-summary Step 2 (3), glean-transcript-skill (9) | Pull out decisions, commitments, open questions and the next meeting, each with where it was said, then write only from that list | No CRM fields, BANT, workflow steps or JSON. Kept "owner unclear" instead of the recap template's "likely owners". |
| Notes order | call-summary internal summary (3), glean-transcript-skill (9) | Next steps split by side; a next-meeting line | Became the person's own action items first, and a next-meeting line only if one was set. |
| Output words | Gold sample (10) and the kit's ban list | No system words; "the invite", not "the retrieved calendar record" | Rule 12. |
| Format question | The kit's error list (error 3) | Default to a document with no question | Decision D-7 replaces D-6. A named format is still honored, and the chat reply offers a web page. |
| Chat reply | Kit context | Two or three sentences, never a repeat of the artifact | Replaces the one-line pointer. |
| Agendas (0.6.0) | Owner decision D-11; Glean meeting-prep (6) lists "agenda context" among its triggers | A shareable agenda for one meeting | Goal, timed items and owners only where named, with private prep left out. Not in the original scope, which excluded agendas. |

Kept because ours already beats the references: the four shared rules, the honest "Couldn't check" part, the hard never-act boundary with a clean handoff when the person asks to act, and "an empty part says so in one line".

Not adopted:
- Named tool calls. The kit's principle is loose instructions, so we diverge on purpose.
- Terminal, install and slash-command steps.
- Glean's "questions they may be asked" section, which makes the output longer for little gain.
- "Likely owners", which conflicts with owner only where stated.
- Anything agent-only from the Agent Library recap template, which is the same public page as source 4.
